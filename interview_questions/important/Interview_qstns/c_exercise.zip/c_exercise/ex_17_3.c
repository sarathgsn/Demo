#include <stdio.h>
int main()
{
	float x = -6;
	int i = x % 2;

	printf("%d\n", i);
}
