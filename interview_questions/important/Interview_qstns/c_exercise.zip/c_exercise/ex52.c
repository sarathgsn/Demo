#include<stdio.h>
register int i;
int main()
{
	register int j;
	printf("%d\n",i);	
//	printf("%u\n",&j);	
	return 0;
}
