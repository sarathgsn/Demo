#include	<stdio.h>
int main()
{
	int p = 40;
	printf("p = %d ,~(-p) = %d,-(~p) = %d", p, ~(-p), -(~p) );
	return	0;
}
