Which data type is most suitable for storing a number 65000 in a 32-bit system?
