#include <stdio.h>

#if 0
const static char a;
int main()
{
	printf("%p \n", &a);
	printf("%d\n",sizeof(a));
}
#endif


#if 1
struct c{
	int a;
	int b;
	struct {
		char d;
	}
};
int main()
{
//	printf("%x\n",10);
//	printf("%d\n",~10);
	printf("%d\n",sizeof(struct c));
}
#endif
