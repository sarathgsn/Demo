#include<stdio.h>
//#include "header.h"


int main(void)





{
    int size[SIZE];
    int top;
    int element;
    int choice;



    while(1) {
         
        printf ("enter the function\n");
        printf ("1. for push\n");
        printf ("2. for pop\n");
        printf ("3. for display\n");
        printf ("4. for exit\n");
        
        scanf("%d", &choice); 

        switch(choice) {
             
            case 1: push();
                    break;

            case 2: pop();
                    break;

            case 3: display();
                    break;

            case 4: exit(1);

            default : printf("please enter the correct choice\n");

        }
    }


          

