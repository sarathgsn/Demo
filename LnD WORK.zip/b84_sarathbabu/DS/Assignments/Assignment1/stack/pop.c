#include "header.h"
#include<stdio.h>
int pop(int top, int *size) 
{    
    int j;
    int num;
//     printf("how many elements you want to remove \n");
  //   scanf("%d",&num);   
   
    if ( top == -1) {
        printf ("pop is not possible\n");
    } else {

        printf("how many elements you want to remove \n");
        scanf("%d",&num);
        for ( j = 0; j < num; j++) { 
        printf ("deleted element is = %d\n",*(size + top));
        top--;}
    } return top;
}
