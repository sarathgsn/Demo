#include<stdio.h>
#include"header.h"
void display(int top, int *size)
{   
    int k; 
    if ( top == -1) {
        printf("display not possible\n");
     } else {
    for ( k = 0; k <= top; k++) {
        printf("%d= element is = %d\n",k, size[k]);
    }
}}
   
