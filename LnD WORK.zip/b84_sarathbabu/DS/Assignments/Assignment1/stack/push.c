#include "header.h"
#include<stdio.h>
#define SIZE 100
int push(int top, int *size, int element)
{  
  int num;
  int i;
//  printf("how many elements you want\n");
//  scanf("%d",&num);
    if (top == 5 - 1) {
        printf("push is not possible\n");
    } else {
        printf("enter the how many elements you want\n");
        scanf("%d", &num);
        for ( i = 1; i <= num; i++) {
        printf("enter the element\n");
        scanf("%d", &element);
        ++top;
        *(size + top) = element;
        }
    } return top; 
}
