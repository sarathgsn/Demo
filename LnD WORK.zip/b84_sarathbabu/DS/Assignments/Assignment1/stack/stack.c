#include<stdio.h>
#include "header.h"
#include<stdlib.h>
int top = -1;
int element;
#define SIZE 100
int size[SIZE];
int  push(int, int*, int);
int  pop(int, int*);
void display(int, int*);
int main(void)

{
//    int size[SIZE];
  //  int top = -1;
  //  int element;
    int choice;
    int result = -1;
    int num;
    int res = -1;
//    int *ptr;
  //  ptr = (int*) malloc (num * sizeof(int)); 

    while(1) {
         
        printf ("enter the function\n");
        printf ("1. for push\n");
        printf ("2. for pop\n");
        printf ("3. for display\n");
        printf ("4. for exit\n");
        
        scanf("%d", &choice); 

        switch(choice) {
             
            case 1:printf("enter the element\n");
                   scanf("%d", &element);
                   result =  push(top, size, element);
                   res = result;
                   printf("%d", size[result]);
                    break;

            case 2: num  = pop(result, size);
                    res = num;
                    printf("%d",num);
                    break;

            case 3: display(res, size);
                    break;

            case 4: exit(1);

            default : printf("please enter the correct choice\n");

        }
    }

}

/*void push()
{
    if (top == SIZE - 1) {
        printf("push is not possible\n");
    } else {
        printf("enter the element\n");
        scanf("%d", &element);
        ++top;
        size[top] = element;
    }
}


void pop() 
{
    if ( top == -1) {
        printf ("pop is not possible\n");
    } else {
        printf ("deleted element is = %d", size[top]);
        top--;
    }
}

void display()
{
 int i;
 for ( i = 0; i <= top ; i++) {
     printf("%d element is = %d\n", i+1, size[i]);
 }
}

*/
