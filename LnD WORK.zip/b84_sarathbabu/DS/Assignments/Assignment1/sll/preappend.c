#include"header4.h"

NODE * preappend(NODE* first, int data)
{
    NODE *new_node = create(data, first);
    first = new_node;
    return first;
}

