#include<stdio.h>
#include<stdlib.h>
#include"header4.h"
int main(void)
{   
    NODE *first = NULL;
    int position;
    int num;
    int element;
    int choice;
    int result;
    while(1) {
    printf("enter the choice\n");
    printf("1. for insert front\n");
    printf("2. for display\n");
    printf("3. for remove front\n");
    printf("4. for remove back\n");
    printf("5. for insert back\n ");
    printf("6. for insert at given position\n");
    printf("7. for insert at before given position\n");
    printf("8. for insert at after given position\n");
    printf("9. for insert at before number\n");
    printf("10. for linked list size\n");
    printf("11. for insert at after number\n");
    printf("12. for insert at middle\n");
    printf("13. for insert at penultimatenode\n");
    printf("14. for remove at given position\n");
    scanf("%d", &choice);

    switch(choice) 
    {
        case 1: printf("enter the element\n");
                scanf("%d", &element);
                first = preappend(first, element);
                break;
        case 2: display(first);
                break;

        case 3: first = remove_front(first);
                break;
        case 4: first = remove_back(first);
                break;
        case 5: printf("enter the element\n");
                scanf("%d", &element);
                first = postappend(first, element);
                break;
        case 6: printf("enter the element\n");
                scanf("%d", &element);
                printf("enter the position\n");
                scanf("%d", &position);
                first = insert_at_position(first, element, position);  
                break;
        case 7: printf("enter the element to be inserted\n");
                scanf("%d", &element);
                printf("enter the position\n");
                scanf("%d", &position);
                first = insert_at_positionbefore(first, element, position);
                break;      
       case 8: printf("enter the element to be inserted\n");
               scanf("%d", &element);
               printf("enter the position\n");
               scanf("%d",&position);
               first = insert_at_positionafter(first, element, position);
               break;
       case 9: printf("enter the element to be inserted\n");
               scanf("%d", &element);
               printf("enter the number\n");
               scanf("%d", &num);
               first = insert_at_number(first, element, num);
               break;
       case 10: result = size1(first);
                printf("%d", result);
                break;
       case 11: printf("enter the element to be inserted\n");
                scanf("%d", &element);
                printf("enter the number\n");
                scanf("%d", &num);
                first = insert_at_number_after(first, element, num);
                break;
       case 12: printf("enter the element\n");
                scanf("%d", &element);
                first = insert_at_middle(first, element);
                break;
       case 13: printf("enter the element\n");
                scanf("%d", &element);
                first = insert_at_penultimate(first, element);
                break;
       case 14: printf("enter the position to be remove\n");
                scanf("%d", &position);
                first = remove_at_position(first, position);
                break;
return 0;
    }
    }
}

