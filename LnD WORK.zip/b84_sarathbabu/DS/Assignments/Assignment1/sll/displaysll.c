#include<stdio.h>
#include"header4.h"

void display(NODE* first)
{ 
    if ( first == NULL) {
        printf("there is no element to dispaly\n");
    }
    while ( first != NULL) {
        printf("display element is= %d\n", first-> data);
        first = first -> link;
    }
}

