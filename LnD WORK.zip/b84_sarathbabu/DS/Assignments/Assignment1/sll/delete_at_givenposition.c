#include"header4.h"
#include<stdio.h>
#include<stdlib.h>
NODE* remove_at_position(NODE *first, int position) 
{   
    int count = 2;
    if (first == NULL) {
        printf("there is no elements to remove\n");
        return first;
    } else if ( first->link == NULL) {    
        printf("removed element is =%d\n", first->data);
        free(first);
        first = NULL;
        return first;
    } else if (( first->link->link == NULL) ||position == 1) {
        NODE *back = first;
        first = first ->link;
        free(back);
        back = NULL;
        return first;
    } else {

      NODE *temp = first->link;
      NODE * front = first;
      while( temp ->link != NULL) {
      if ( count == position ) {
          front ->link = temp->link;
          free(temp);
          temp = NULL;
          front = first;
          return first;
      } else { 
          temp = temp->link;
          front = front->link;
          count++;
      }
      } 
    }
}
       
          
