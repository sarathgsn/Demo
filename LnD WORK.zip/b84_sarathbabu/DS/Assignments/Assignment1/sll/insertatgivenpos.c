#include"header4.h"
#include<stdlib.h>
#include<stdio.h>

NODE* insert_at_position(NODE *first, int  data, int position)
{   if ( first == NULL) {
    printf("there is no elements\n");
    return first;
    }/* else if( position > size1(first)) {
       // printf("this position is not there\n");
       
    } */
   else if( position == 0 || position == 1 + size1(first)) { 
        first = preappend(first, data);
        return first;
    } else if( position > size1(first)) {
           printf("this position is not available\n");
           return first;
           } 
   
           else { 
               int count = 1;
        NODE *dum = NULL;
        NODE *p = create (data, dum); 
        NODE *temp = first;
              while(temp->data) {
                  if (count == position)
                       break;
                  else 
                       { 
                         temp = temp -> link;
                           count++;
                        }
                            }
                              p -> link = temp ->link;
                                temp -> link = p;
                                  p = first;
                                  return first;
               }
}

