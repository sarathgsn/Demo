#include"header4.h"
#include<stdio.h>
#include<stdlib.h>
NODE* remove_back(NODE *first) 
{
    if (first == NULL) {
        printf("there is no elements to remove\n");
    } else if ( first->link == NULL) {    
        printf("removed element is =%d\n", first->data);
        free(first);
        first = NULL;
    } else {
        NODE *back = first;
        while ( back-> link != NULL) {
            back = back -> link;
        } 
              
            free(back);
            back = NULL;
 //           return first;
    } return first;
}




