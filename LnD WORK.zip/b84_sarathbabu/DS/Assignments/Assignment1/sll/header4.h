
typedef struct node 
{
    int data;
    struct node *link;
}NODE;



NODE* create(int, NODE*);
NODE* preappend(NODE*, int);
void display(NODE*);
NODE* remove_front(NODE*);
NODE* remove_back(NODE*);
NODE* postappend(NODE*, int);
NODE* insert_at_position(NODE*, int, int);
NODE* insert_at_positionbefore(NODE*, int, int);
NODE* insert_at_positionafter(NODE*, int, int);
NODE* insert_at_number(NODE*, int, int);
NODE* insert_at_number_after(NODE*, int, int);
int size1(NODE*);
NODE* insert_at_middle(NODE*, int);
NODE* insert_at_penultimate(NODE*, int);
NODE* remove_at_position(NODE*, int);
