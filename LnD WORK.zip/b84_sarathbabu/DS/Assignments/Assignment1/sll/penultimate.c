#include"header4.h"
#include<stdlib.h>
#include<stdio.h>

NODE* insert_at_penultimate(NODE *first, int  data)
{  
     if ( first == NULL) {
         printf("there is no  elements\n");
         return first;
     } else if ( first-> link == NULL) {
         first = preappend(first, data);
         return first;
      } else {
        int count = 1;
        int res;
        NODE *dum = NULL;
        NODE *p = create (data, dum); 
        NODE *temp = first;
              while(temp->link->link != NULL) {   
                     temp = temp->link;
               }
              p ->link = temp->link;
              temp->link = p;
              p = temp;
              return first;
      }  
}
