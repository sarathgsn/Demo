#include"header4.h"
#include<stdio.h>

int size1(NODE *first)
{
    int size = 0;
    if (first == NULL) {
        printf("in list zero elements\n");
    } else {
        while (first) {
                size++;
                first = first->link;
        } return size;
    }
}

