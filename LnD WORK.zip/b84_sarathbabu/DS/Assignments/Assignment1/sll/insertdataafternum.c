#include"header4.h"
#include<stdlib.h>
#include<stdio.h>

NODE* insert_at_number_after (NODE *first, int  data, int number)
{   if ( first == NULL) {
    printf("there is no elements\n");
    return first;
    } else if ( first -> link == NULL) {
         first = create(data, first);
    } else {
        int flag = 0;
        int count = 0;
        NODE *dum = NULL;
        NODE *p = create (data, dum); 
        NODE *temp = first;
        NODE *tem;
        int res1;
              while(temp -> link != NULL) {
                  if ( temp-> data == number) {
                      flag = 1;
                       break;
                  }  else 
                       { 
                         temp = temp -> link;
                         ++count;
                        }
                 } if ( flag == 0) {
                     printf("taht number is not available\n");
                     exit(1);
                     return first;
                 } else{
                      first = insert_at_positionafter(first, data, count);
                      return first; 
                 }

}
}
