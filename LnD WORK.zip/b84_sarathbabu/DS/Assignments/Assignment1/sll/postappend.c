#include"header4.h"
#include<stdlib.h>

NODE* postappend(NODE* first, int data)
{   
    NODE *dummy = NULL;
    if (first == NULL) {
        NODE *new1_node = create(data, first);
        first = new1_node;
        return first;
    } else{

    NODE *temp = first;
    NODE *new_node = create(data, dummy);
    while(temp->link != NULL) {
        temp = temp->link;
    } temp -> link = new_node;
     return first;
    }
}


