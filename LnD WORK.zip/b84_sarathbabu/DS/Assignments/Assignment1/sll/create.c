#include<stdio.h>
#include"header4.h"
#include<stdlib.h>

NODE * create ( int data, NODE * first) 
{
    NODE *p;
    p = (NODE *)malloc(sizeof(NODE));
    if( p == NULL) {
        printf("error in creating new node\n");
    } else 
        p -> data = data;
        p -> link = first;
        return p;
}
