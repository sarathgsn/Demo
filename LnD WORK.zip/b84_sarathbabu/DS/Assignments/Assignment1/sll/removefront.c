#include"header4.h"
#include<stdio.h>
#include<stdlib.h>

NODE* remove_front(NODE *first)
{
    NODE *remove = first;
    if ( first == NULL) {
        printf("there is no elements to remove\n");
        return first;
    }
    else if( first-> link == NULL)  {
            printf("removed element is = %d\n", first->data);
            free(first);
            first = NULL; 
            return first;       
    }  else {
            first = first->link;
            free(remove);
            remove = NULL;
            return first;
    }
}


