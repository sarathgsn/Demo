#include"header4.h"
#include<stdlib.h>
#include<stdio.h>

NODE* insert_at_middle(NODE *first, int  data)
{  
     if ( first == NULL) {
         printf("there is no  elements\n");
         return first;
     } else if ( first-> link == NULL) {
         first = preappend(first, data);
         return first;
      } else {
        int count = 1;
        int res;
    //  NODE *dum = NULL;
    //    NODE *p = create (data, dum); 
        NODE *temp = first;
              while(temp) {
                        count++;
                        temp = temp->link;
               }
            res = count/2;
            first = insert_at_position(first, data, res);
            return first;
      }  
}
