#include"header4.h"
#include<stdlib.h>
#include<stdio.h>

NODE* insert_at_positionbefore(NODE *first, int  data, int position)
{ 
       if( first == NULL) {
           printf(" there is no 0 position\n");
           return first;
       } else if( position == 1 ) {
        first = preappend(first, data);
        return first;
    } else if( position > size1(first)) {
        printf("that position is not available\n");
    } else {
        int count = 1;
        NODE *dum = NULL;
        NODE *p = create (data, dum); 
        NODE *temp = first;
              while(temp->data) {
                  if (count == position -1)
                       break;
                  else 
                       { 
                         temp = temp -> link;
                           count++;
                        }
                            }
                              p -> link = temp ->link;
                                temp -> link = p;
                                  p = first;
                                  return first;
                }
}

