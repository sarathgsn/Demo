#include"header4.h"
#include<stdlib.h>
#include<stdio.h>

NODE* insert_at_number (NODE *first, int  data, int number)
{   if ( first == NULL) {
    printf("there is no elements\n");
    return first;
    } else if ( first -> link == NULL) {
         first = create(data, first);
    } else {
        int flag = 0;
        int count = 1;
        NODE *dum = NULL;
        NODE *P = create (data, dum); 
        NODE *temp = first;
        NODE *tem;
        int res1;
              while(temp->data) {
                  if ( temp-> data == number){
                      flag = 1;
                       break;
                  }
                  else 
                       { 
                         temp = temp -> link;
                          count++;
                        }
                 }
                   if( flag == 0){
                       printf("that number is not available\n");
                       exit(1);
                       return first;
                 } else first = insert_at_positionbefore(first, data, count);
                      return first; 
}
}
