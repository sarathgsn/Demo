#include<stdio.h>
#include"header2.h"
void display(int rear, int front, int *size) 
{
   int o;
  if ( rear == -1) {
     printf("display is not possible\n ");
  } else { 
      ++front;
     for ( o = front; o <= rear; o++) {
        printf("%d element is = %d\n", o, *(size+o));
     }
  }
} 
