 int enqueue(int, int, int*);
 int dequeue(int, int, int*);
 void display(int, int, int*);
