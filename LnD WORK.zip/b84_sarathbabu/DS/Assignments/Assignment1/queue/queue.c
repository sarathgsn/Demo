#include<stdio.h>
#include<stdlib.h>
#include"header2.h"
#define SIZE 100
int size[SIZE];
int rear = -1;
int front = -1;
int element;

int main()
{   int str = -1, str1 = -1;
    int result = -1;
    int choice;
    while(1) {
    printf ("enter your choice\n");
    printf ("1. for enqueue\n");
    printf ("2.for dequeue\n");
    printf ("3. for display\n");
    printf ("4. for exit\n");
    scanf ("%d", &choice);


    switch(choice) {
         
        case 1: result =  enqueue(rear, front, size);
                str = result;
                break;
        case 2:  result = dequeue(result, front, size);
                str1 = result;
                break;
        case 3: display(str, str1, size);
                break;
        case 4: exit(1);
        
        default : printf("enter the correct choice\n");


    }
}
}
/* 
void enqueue()
{
    if (rear == SIZE -1) {
        printf("enqueue is not possible\n");
    } else {
        printf("enter the element\n");
        scanf("%d", &element);
        ++rear;
        size[rear] = element;
    }
}

void dequeue()
{
    if ( rear == -1) {
        printf("dequeue is not possible\n");
    } else {
        ++front;
        printf("deleted element is = %d",size[front]);
    }
}


void display() 
{    int i;
    if ( rear == -1) {
        printf("display is not possible\n");
    } else {
        for ( i = front; i <= rear; i++) {
            printf("%d element is = %d", i, size[front]);
        }
    }
} */
