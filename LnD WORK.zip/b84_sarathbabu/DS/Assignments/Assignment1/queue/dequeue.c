#include "header2.h"
#include<stdio.h>
int dequeue(int rear, int front, int *size)
{    int n, z;
      if ( rear == -1) {
        printf("dequeue is not possible\n");
    } else { 
        printf("how many elements you want to remove\n");
        scanf("%d", &n);
        for (z = 0; z < n; z++) {
        ++front;
        printf("deleted element is = %d\n",*(size + front));
        }
//        ++front;
    } return front;
}

