#include<stdio.h>
#include"header2.h"
int enqueue(int rear, int front, int*size)
{   int num;
    int m;
    int element;
    if (rear == 5 -1) {
        printf("enqueue is not possible\n");
    } else {
        printf("how many elements you want to insert\n");
        scanf("%d",&num);
        for(m = 0; m < num; m++){
        printf("enter the element\n");
        scanf("%d", &element);
        ++rear;
       *(size + rear) = element;
        }
    } return rear;
}

