#include<stdio.h>
#include"header3.h"
#include<stdlib.h>
#define SIZE 5
int main(void)
{  
    int choice;
    int rear = -1;
    int front = -1;
    int element;
    int size[SIZE];
    int count = 0;
    int res = -1, res1 = -1;
     while(1) {
        printf("enter the choice\n");
        printf("1. for insert\n");
        printf("2. for delete\n");
        printf("3. for display\n");
        printf("4. for exit\n");
        scanf("%d", &choice);
     switch(choice) {
         case 1:
                res =  insert(rear, &count,  size, element);
                printf("%d",res);
                break;
         case 2:
                res1 = delete(&count, front, size);
                break;
         case 3:display(res, res1, size);
               break;
         case 4:exit(1);
               break;
         case 5: printf("enter the correct choice\n");

      }
    }
}   
