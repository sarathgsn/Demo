#include"header3.h"
#include<stdio.h>
#define SIZE 5
 
int  delete(int *count, int front, int *size)
{   
    int num,p;
    if (*count ==  0) {
        printf("deletion is not possible\n");
      } else {
           printf("how many elements you want to remove\n ");
           scanf("%d", &num);
             if (num > *count) {
                printf("there is no elemnts\n");
                } else {
                       for( p =  0; p < num; p++) { 
                        front = (front + 1) % SIZE;
                        (*count)--;
                         printf("deleted element is %d\n",*(size+front)); 
                       }
                }
      } return front;
}
