#include"header3.h"
#include<stdio.h>
#define SIZE 5

int insert( int rear, int *count,  int *size, int element) 
{  
      int num, p;
    if ( *count == SIZE -1) {         //checking for queue is full or not
           printf("insertion is not possible\n");
    } else {
           printf("how many elements you want to insert\n");
           scanf("%d",&num);
           if (num > SIZE -1) {
               printf("please enter valid elements num\n");
           } else{
          for (p = 0; p < num; p++) {
             if (*count == SIZE -1){
                printf("insert is not possible\n");
             } else {
                   rear = (rear + 1) % SIZE ; //for doing circular queue
                   printf("enter the elment\n");
                   scanf("%d", &element);
                   size[rear] = element;
                    ++*count;
                   printf(" element is =%d\n",  *(size + rear));
           }
          }
    }
    } return rear;
}    
