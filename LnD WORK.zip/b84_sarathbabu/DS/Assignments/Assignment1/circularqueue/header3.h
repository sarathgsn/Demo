int insert(int, int*, int*, int);
int delete(int*, int, int*);
int display(int, int, int*);
