#include<stdio.h>
#include"header3.h"

int display(int rear, int front, int *size)
{   int k;
    if(rear == -1) {
        printf("display is not possible\n");
    }else {
        for ( k = ++front; k <= rear; k++) {
            printf("%d element is%d\n",k,  *(size + k));
        }
    }
}

