#include"header.h"
#include<stdio.h>


int binarysearch(int *ptr, int l, int num, int element) 
{  
   
    int l1 = l,u = num;

    int mid = l1 + u/2;
   
   
    if ( *(ptr +mid) == element) {
//        printf("element is found\n");
       return 1;
    } else if ( mid == num) {
        printf("element is not found\n");
    } else if ( *(ptr + mid) < element ) {
        l = mid;
        u = num;
        binarysearch(ptr, l, u, element);
    } else {
        l = 0;
        u = mid - 1;
        binarysearch(ptr, l, u, element);
 }
}
