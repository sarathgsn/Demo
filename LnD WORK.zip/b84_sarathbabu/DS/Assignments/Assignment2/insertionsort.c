#include"sorting.h"



int* insertion_sort(int *ptr, int num)
{
    int j, k;
    int temp;
    for (j = 0; j <= num; j++) {
        for ( k = j+1; k <= num; k++) {
        if ( *(ptr + j) < *(ptr + k)) {
            continue;
          } else {
            temp = *(ptr + j);
            *(ptr + j) = *(ptr + k);
            *(ptr + k) = temp;
        }  
    }
}
  return ptr;
}                    
