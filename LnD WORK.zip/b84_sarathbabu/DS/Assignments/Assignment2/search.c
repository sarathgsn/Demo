#include"header.h"

int search(int *ptr, int num, int data)
{
    int i, j;
    for ( i = 0; i < num; i++) {
         if ( *(ptr + i) == data) {
             return 1;
         } //else return 0;
    } return 0;
}
