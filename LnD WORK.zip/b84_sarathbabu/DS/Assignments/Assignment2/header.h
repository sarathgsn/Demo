int search(int*, int, int);
int* sort(int*, int);
int binarysearch(int*, int, int, int);
