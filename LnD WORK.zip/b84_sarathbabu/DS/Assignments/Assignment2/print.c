#include"sorting.h"
#include<stdio.h>

void display (int *str, int num)
{
    int m;
    for ( m = 0; m <= num; m++) {
        printf("Element is\n %d", *(str + m));
    }
}
