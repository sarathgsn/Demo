#include<stdio.h>
#include<stdlib.h>
#include"header.h"
int main(void)
{  
    int choice;
    int i, j, k;
    int num;
    int *p;
    int str1;
    int *str;
    int res;
    int element;
    int l = 0;
    printf("enter the size of array\n");
    scanf("%d", &num);
    p = (int*)malloc(num * sizeof(int));
    if ( p == NULL) {
        printf("memoery is not allocated\n");
    } else  
        for ( i = 0; i < num; i++) {
        printf("enter the elements\n");
            scanf("%d", p + i);
        }        
    while(1) {
        printf("enter the choice\n");
        printf("1 >> for linear search\n");
        printf("2 >> for sorting\n");
        printf("3 >> for binary search\n");
       
       scanf("%d",&choice);
       
        switch(choice) 
        {
         case 1:   printf("enter the element to be search\n");
                   scanf("%d", &element);
                   res = search(p, num, element);
                   if ( res == 1) 
                   printf("element is found\n");
                   else printf("element is not found\n");  
                   break;  
  
         case 2:   str = sort(p, num);
                   for ( k = 0; k < num; k++) {
                      printf("%d\n", *(str + k));
                      }
                   break;
         case 3:   if ( p == NULL) 
                    printf("please enter the array by using choice 1\n");
                   else {
                   str = sort(p, num);
                   printf("enter the element to be search\n");
                   scanf("%d",&element);
                   str1 = binarysearch(str, l, num, element);
                   if ( str1 == 1)
                   printf("element is found\n");
                //   else printf("element is not found\n");
                   }
                   break;
                     
        }
    }
 return 0;
}




