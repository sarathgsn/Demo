#include"sorting.h"
int* selectionsort(int *ptr, int num)
{   
    int *ptr2;
    ptr2 = ptr;
    int i, j;
    int res;
    for ( i = 0; i <= num; i++) {
        for ( j = i + 1; j <= num; j++) {
            if (*(ptr2 + i) < *(ptr2 + j)) {
                continue;
            }  else { 
                res = *(ptr2 + i);
                *(ptr2 + i) = *(ptr2 + j);
                *(ptr2 + j) = res;
            }
        }
    }
    return ptr2;
}
