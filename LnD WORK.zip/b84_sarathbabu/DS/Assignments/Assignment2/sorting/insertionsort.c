#include"sorting.h"



int* insertion_sort(int *ptr, int num)
{  
    int i; 
    int *ptr2;
    ptr2 = ptr;
    int j;
    int temp;
    for (i = 0; i <= num; i++) {
    for (j = 0; j <= num; j++) {
        if ( *(ptr2 + j) > *(ptr2 +(j+1))) {
            temp = *(ptr2 + j);
            *(ptr2 + j) = *(ptr2 +(j+1));
            *(ptr2 +(j+1)) = temp;
        }
    }
    } return ptr2;
} 
                     
