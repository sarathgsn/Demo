#include"sorting.h"


int* myqsort(int *array, int low, int high)
{ 
    if (low >= high) 
        return;
    else { 
        int res;
    res = pivot_pos(array, low, high);
    printf("%d", res);
   myqsort(array, 0, res - 1);
   myqsort(array, res + 1, high);
    return array;
    }
}

int  pivot_pos(int *array, int low, int high)
{
    int temp;
    int pivot = *(array + low);
    int i = low + 1;
    int j = high -1;
    if (i > j) { 
       temp = *(array + j);
      *(array + j) = pivot;
       pivot = temp;
       return j;
    } else {
            if ( *(array + i) < pivot) {
                i++;
            } else if (*(array + j) > pivot) {
                j--;
            } else if (i < j) {
                temp = *(array + i);
                *(array + i) = *(array + j);
                *(array + j) = temp;
                 i++;
                 j--;
             pivot_pos(array, i, j);
            }
        }

}        

