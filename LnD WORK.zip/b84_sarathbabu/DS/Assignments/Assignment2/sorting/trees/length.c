#include"binarytree.h"
#include<stdlib.h>
int length(node *first)
{
//   int depth = 0;
  if ( first == NULL) 
     return 0;
  else {
     return (length(first -> llink) + 1 + length(first -> rlink));
  } 
} 
