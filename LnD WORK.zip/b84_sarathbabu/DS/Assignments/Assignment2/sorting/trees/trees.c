#include<stdio.h>
#include<stdlib.h>
#include "binarytree.h"
int main(void)
{
    node * first = NULL;
    int data;
    int choice;
    int res;

    while(1) {
        printf("enter the choice\n");
        printf("1. for insertion or creating binary tree\n");
        printf("2. for preorder\n");
        printf("3. for postorder\n"); 
        printf("4. for inorder\n");
        printf("5. for length\n");
        scanf("%d", &choice);
        switch(choice) {

            case 1: printf("enter the element to be inserted\n");
                    scanf("%d", &data);
                    first = binarytree(first, data);
                    break;
            case 2: preorder(first);
                    break;
            case 3: postorder(first);
                    break;
            case 4: inorder(first);
                    break;
            case 5: res = length(first);
                    printf("%d\n", res);
                    break;
        }
    }
return 0;
}

