#include "binarytree.h" 
#include<stdlib.h>


node* binarytree(node *first, int data)
{   
    node *temp;
    node *p = NULL;
    if (first == NULL) {
       first = create (first, data);
        return first;
    } else if ( data > (first -> data)) {
        p = create(p, data);
        temp = first;
        while ( temp -> rlink != NULL) {
            temp = temp -> rlink;
        } if ( data > (temp -> data)) {
            temp -> rlink = p;
            p = first;
            return first;
        } else {
            temp -> llink = p;
            p = first; 
            return first;
        }
    } else {
        node *temp1;
        temp1 = first;
        p = create(p, data);
        while ( temp1 -> llink != NULL) {
            temp1 = temp1 -> llink;
        } if ( data < (temp1 -> data)) {
            temp1 -> llink = p;
            p = first;
            return first;
        } else {
            temp1 -> rlink = p;
            p = first;
            return first;
        }
    } return first;
}
