#include "binarytree.h"
#include<stdio.h>
node* preorder( node *first)
{      
    if ( first == NULL ) {
        return first;
    } else {
          printf("%d\n", first -> data);
          preorder(first -> llink);
          preorder(first -> rlink);
    }
}

