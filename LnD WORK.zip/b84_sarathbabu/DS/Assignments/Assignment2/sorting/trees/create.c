#include "binarytree.h"
#include<stdio.h>
#include<stdlib.h>
node* create(node *first, int data)
{
    node *p;
    p = (node*)malloc (sizeof(struct node));
    if ( p == NULL ) {
        printf("error in creating node\n");
    } else {
        p -> data = data;
        p -> llink = NULL;
        p -> rlink = NULL;
        return p;
    }
}
