#include<stdio.h>
#include"binarytree.h"
node* postorder(node *first)
{
    if ( first == NULL) {
//       printf("there is no elements\n");
        return first;
    } else {
      //  printf("%d\n", first -> data);
        postorder(first -> llink);
//        printf("SOnu\n");
        postorder(first -> rlink);
        printf("%d\n", first -> data);
    }
}

