#include<stdio.h>
#include "binarytree.h"
node* inorder(node *first)
{
    if ( first == NULL) {
        return first;
    } else {
        inorder(first -> llink);
        printf("%d\n", first -> data);
        inorder(first -> rlink);
    }
}

