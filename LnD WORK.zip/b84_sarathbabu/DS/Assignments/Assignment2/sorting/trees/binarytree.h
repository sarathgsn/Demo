//node* binarytree(node*, int);
//node* create(node*, int);
//node* preoder(node*);

typedef struct node 
{
    int data;
    struct node *llink;
    struct node *rlink;
}node;

node *binarytree(node*, int);
node *create(node*, int);
node *preorder(node*);
node *postorder(node*);
node *inorder(node*);
int length(node*);
