#include"sorting.h"
#include<stdio.h>

void display (int *str, int num)
{
    int m;
    for ( m = 1; m < num +1; m++) {
        printf("%d element is =%d\n", m, *(str + m));
    }
}
