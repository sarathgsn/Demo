int *insertion_sort(int*, int);
void display(int*, int);
int *selectionsort(int*, int);
int *bubble_sort(int*, int);
int *myqsort(int*, int, int);
int pivot_pos(int*, int, int);
