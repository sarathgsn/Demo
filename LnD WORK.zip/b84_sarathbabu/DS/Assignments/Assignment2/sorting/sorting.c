#include<stdio.h>
#include<stdlib.h>
#include"sorting.h"
int main(void)
{   
    int i;
    int low = 0;
    int num;
    int *p;
    int choice;
    int *res;
   
    printf("enter the array size\n");
    scanf("%d", &num);
    p = (int*)malloc (num * sizeof(int));
    for ( i = 0; i < num; i++) {
        printf("enter the element\n");
        scanf("%d", p + i);
    }

//    display(p, num);

    while(1) {
        printf("enter the choice\n");
//        printf("1---for display\n");
        printf("1---for insertion sort\n");
        printf("2---for selectionsort\n");
        printf("3---for bubblesort\n");
        printf("4---for qsort\n");




        scanf("%d", &choice);

        switch(choice) {
           
//            case 1: display(p, num);
  //                  break;
            case 1: res =(int*) insertion_sort(p, num);
                    display(res, num);
                    break;
            case 2: res =(int*) selectionsort(p, num);
                    display(res, num); 
                    break;                   
            case 3: res =(int*) bubble_sort(p, num);
                    display(res, num);
                    break;
            case 4:  myqsort(p, low, num);
                    display(p, num);
                    break; 




        }
    }
    return 0;
}
