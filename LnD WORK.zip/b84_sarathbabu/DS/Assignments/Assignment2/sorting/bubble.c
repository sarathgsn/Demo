#include"sorting.h"


int *bubble_sort(int *ptr, int num) 
{
    int *ptr2;
    ptr2 = ptr;
    int i, j, temp;
    for (i = 0; i <= num; i++)
     {
     for ( j = 0; j <= num -i; j++) 
        {
        if ( *(ptr2 + j) > *(ptr2 + (j+1)))
        {
        
                temp = *(ptr2 + j);
                *(ptr2 + j) = *(ptr2+(j+1));
                *(ptr2 +(j+1)) = temp;
        }
       }
    }
    return ptr2;
}
