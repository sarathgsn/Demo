#include<stdio.h>
//int *ptr  = 0;
//*ptr = 100;
int main(void)
{ 

//    char *p;
 //   int n = 0x5042;
//    p = (char *)&n;
//    printf("%d", *p);
    int a   = 10;
    int b = &a + 1;
//     (&a+ 1) =20;
//    char d = 'b';
//    int c;
//    int *ptr = &10;
//    int b = &a;
//    int *ptr = 0x08041234;
//    *ptr = 100;
  //  int b = &(*ptr);
//    printf("%d\n", *(&b));
//    int *ptr = &a;
  //  *ptr = 10;
//   printf("%d\n", *((int *)b));
//   printf("%d",*ptr);
 printf("%d\n",&a);
printf("%d\n", b);
   



}
