#include<stdio.h>
#include<stdlib.h>
#include"header.h"
int main(void)
{
    int choice;                  
    node *first = NULL;         
    int data;

    while (1) {
        printf ("enter the choice\n");
        printf ("1---->Inserting elements\n");
        printf ("2---->Preorder\n");
        printf ("3---->Post order\n");
        printf ("4---->Inorder\n");
        printf ("5---->level order\n");
        printf ("6---->exit\n");
        scanf ("%d", &choice);

        switch (choice) {

            case 1 :printf("enter the element to be inserted\n");
                    scanf("%d", &data);
                    first = binarytree(first, data);  //invoking the function for inserting
                    break;

           case 2 :  pre_order(first);      // invoking the preorder fun
             //        if ( first == NULL)
             //          printf("there is no element\n"); 
                    break;

           case 3 :  post_order(first);      // invoking the postorder
              //    if ( first == NULL)
              //         printf("there is no element\n");
                    break;

           case 4 : in_order(first);           // invoking the inorder
             //      if (first == NULL)
             //          printf("there is no element\n");
                    break;

           case 5 : level_order(first);        // invoking the level order
                    break;
           case 6 : exit(1);
                    

           default : printf("please enter the valid choice\n");
        }
    }
    return 0;
}
