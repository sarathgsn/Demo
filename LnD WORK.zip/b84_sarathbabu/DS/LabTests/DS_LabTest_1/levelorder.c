#include<stdio.h>
#include"header.h"
#include<stdlib.h>
node* level_order(node *first)
{ 

    node *temp = first;
    node *temp1;
    node *temp2;
    
    if ( temp == NULL) {
        return first;
    } else if ( (temp -> llink == NULL || temp -> rlink == NULL)) { // if both left link and right link are null
        printf ("%d\n", temp -> data);
        return first;
    } else {
        printf ("%d\n", temp -> data);         
        printf ("%d\n", temp -> llink -> data);
        printf ("%d\n", temp -> rlink -> data);
        temp1 = temp -> llink -> llink;
        temp2 = temp -> rlink -> rlink;
        level_order(temp1);          // calling recursively level order function
        level_order(temp2);

    }
} 


/*
  
 int flag = 1;
node *temp = first;
node *temp1 = first;
  node * temp = first;
  if ( temp == NULL) {
    return first;
  } else {  
    printf("%d", temp -> data);
     if (flag) {
         level_order (temp -> llink, 0);
     } else {
         level_order (temp -> rlink, 1);
     }
  }
}

*/
