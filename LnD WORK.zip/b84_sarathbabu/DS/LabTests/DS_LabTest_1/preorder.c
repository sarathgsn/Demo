#include "header.h"
#include<stdio.h>
node* pre_order( node *first)    // for pre order 
{      
    if ( first == NULL ) {          //checking the termination condition
        return first; 
    } else {
        printf("%d\n", first -> data);
        pre_order(first -> llink);    // calling recursively to the preorder
        pre_order(first -> rlink);
    }
}

