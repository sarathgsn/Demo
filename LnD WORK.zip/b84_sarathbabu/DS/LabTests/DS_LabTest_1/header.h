typedef struct node 
{
    int data;
    struct node *llink;
    struct node *rlink;
}node;
node* binarytree(node*, int);
void display(node*);
node* pre_order(node*);
node* post_order(node*);
node* in_order(node*);
node* level_order(node*);
