#include "header.h" 
#include<stdlib.h>


node* binarytree(node *first, int data)
{   
    node *temp = first;
    node *temp1 = first;
    node *ptr = NULL;
    if (first == NULL) {            // checking the initial condition  
       first = (node*) create (first, data); //if no elements create node
        return first;
    } else {
        ptr = (node*) create(ptr, data);
     if ( data > (first -> data)) {   // if given data is greaterthan root node insert at right
        while ( temp -> rlink != NULL) {  // checking termination of tree
            temp = temp -> rlink;
        } if ( data > (temp -> data)) {  // inserting at right
            temp -> rlink = ptr;
            ptr = first;
            return first;
        } else {
            temp -> llink = ptr;        // inserting at left
            ptr = first; 
            return first;
        }
    } else {
        while ( temp -> llink != NULL) {  //if given data is lessthan root node insert at left side
            temp = temp -> llink;
        } if ( data < (temp1 -> data)) {  // insert at left
            temp1 -> llink = ptr;
            ptr = first;
            return first;
        } else {
            temp -> rlink = ptr;         //insert at right
            ptr = first;
            return first;
        }
    }
    } return first;
}
