#include<stdio.h>
#include "header.h"
node* in_order(node *first)       // inorder function
{
    if ( first == NULL) {        // termination condition
//        printf("there is no element\n");
        return first;
    } else {
        in_order(first -> llink);  // calling recursively to inorder
        printf("%d\n", first -> data);
        in_order(first -> rlink);  // calling recursively to inoder
    }
}

