#include<stdio.h>
#include"header.h"
node* post_order(node *first)   // postorder  function
{
    if ( first == NULL) {       // checking the termination 
//        printf("there is no element\n");
        return first;
    } else {
        post_order(first -> llink);  //calling recursively to the postorder
        post_order(first -> rlink);
        printf("%d\n", first -> data);
    }
}

