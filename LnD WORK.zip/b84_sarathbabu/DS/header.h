struct node
{
    int data;
    struct  node *llink;
    struct node *rlink;
}node;

