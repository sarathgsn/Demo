
/* TCP server program */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>

#define MAX 100

int main(void)

{

    int sock_fd ;
    int sock_fd_clnt ;
    struct sockaddr_in v_bnd ;
    struct sockaddr_in v_acpt ;
    int len ;
    int ret_value ;
    char *ptr ;
    char buf[MAX] ;

    sock_fd = socket ( AF_INET, SOCK_STREAM, 0 ) ;

/*    if ( (-1) == sock_fd ) {
        perror ("socket") ;
        return -1 ;
    }*/

    v_bnd.sin_family = AF_INET ;
    //v_bnd.sin_port = htons (4000) ;
    v_bnd.sin_addr.s_addr = inet_addr ("172.16.5.147");

    len = sizeof(v_bnd) ;

    ret_value = bind ( sock_fd, (const struct sockaddr *)&v_bnd, (socklen_t)len ) ;

/*    if ( (-1) == ret_value ) {
        perror ("bind") ;
        return -1 ;
    }*/

    ret_value = listen (sock_fd, 5) ;

/*    if ( (-1) == ret_value ) {
        perror ("listen") ;
        return -1 ;
    }*/

    printf ("server : Waiting for connections \n") ;

    sock_fd_clnt = accept ( sock_fd, (struct sockaddr *)&v_acpt, (socklen_t *)&len ) ;

/*    if ( (-1) == sock_fd_clnt ) {
        perror ("accept") ;
        return -1 ;
    }*/

    printf ("server : Connection established \n") ;

    while (1) {
    
        ret_value = read ( sock_fd_clnt, buf, sizeof (buf) ) ;

      /*  if ( (-1) == ret_value ) {
            perror ("read") ;
            return -1 ;
        }*/

        printf ("client : %s \n", buf) ;

        ptr = fgets ( buf, sizeof (buf), stdin ) ;

     /*   if ( NULL == ptr ) {
            perror ("fgets") ;
             return -1 ;
        }*/
 
        ret_value = write ( sock_fd_clnt, buf, sizeof (buf) ) ;

    /*    if ( (-1) == ret_value ) {
            perror ("read") ;
            return -1 ;
        }*/

    }
    close ( sock_fd ) ;

    return 0 ;
}
