#include<stdio.h>
#include<string.h>
#define SIZE 100   // definition 
int num = 0;
int char_sappend(char*, char*);
int main(void)
{   
    char sbuf[SIZE];    // first string
    char  dbuf[SIZE];  // second string
    int  char_ptr;  //character pointer
    printf ("enter sbuf\n");
    scanf ("%s", sbuf);
    printf("enter dbuf");
    scanf ("%s", dbuf);
    num = strlength(dbuf);
   // printf("%d",num);
    char_ptr = char_sappend(sbuf, dbuf); // invoking function
 if(char_ptr== num)
     printf("Substring found\n");
 else
    printf ("Substring not found\n");
  
        
    
}

int strlength (char *sbuf)
{ 
    int i; 
    int len=0;     
    for(i=1; *sbuf != '\0'; i++){
        ++len;
        ++sbuf;
    }
    return len;
}   

 int char_sappend( char *sbuf, char*dbuf) {
           
     int j;
    int count = 0;
             for (j=0; *sbuf != '\0' ; j++) {
                if( *sbuf == *dbuf )  {
                    sbuf++;
                    dbuf++;
                    count++;
                  }
                else sbuf++;
         
             }
             return count;
 }




