#include<stdio.h>
int main(void)
{
    int arr[3] = { 1, 2, 3};
    printf("%d",arr[-1]);
    return 0;
}
