#include<stdio.h>
fun (int a, int b)
{
   if ( a == 11)
      return 3;
   else 
      return 6;
}


int main(void)
{
    int a, b, c;
    a = 10;
   b = 11;
  c = fun(10, 20);
 printf("%d",c);
}


