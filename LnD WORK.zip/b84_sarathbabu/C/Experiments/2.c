#include<stdio.h>
int main(void)
{
//    unsigned int a =  20;
  //  int b = -6;
    if (-6 > 20) 
        printf("a is lescnaf(""); than b\n");
    else 
        printf("a is greater than b\n");
}
