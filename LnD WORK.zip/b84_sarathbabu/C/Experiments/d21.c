#include<stdio.h>
int main(void)
{
    char a[1][5] = { "hello"};
    printf("%s", a[0]);
    return 0;
}
