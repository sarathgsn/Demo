#include<stdio.h>
int g_var;
int main()
{
    printf("%d",g_var);
}
