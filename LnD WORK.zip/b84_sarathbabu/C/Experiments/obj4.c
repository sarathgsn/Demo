#include<stdio.h>
const int a = 23;
//int *p = &a;
int *p = (int *)&a;
*p =100;
int main(void)
{ 
//     *p = 100;
//    printf("a = %d\n", a);
 //   const int a = 23;
 //   int *p = (int *)&a;
 //   *p = 100;
    printf("value of p =%d\n",*p);
    printf("value of a=%d\n", a);
    return 0;
}

