#include<stdio.h>
int main(void)
{
    int a;
    int b, c;
    printf("enter the numbers\n");
    scanf("%d%d", &a, &b);
    c = a | b;
    printf("%d", c);
}
