#include<stdio.h>
int main(void)
{
    int arr[10] = {1,2,3};
    printf("%p\n",arr);
    printf("%p\n",arr+1);
    printf("%p",&arr+1);
return 0;
}
