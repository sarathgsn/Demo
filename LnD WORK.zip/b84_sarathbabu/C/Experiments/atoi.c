#include<stdio.h>
int main()
{
    int i,n;
    char c[100];
    printf("enter a string");
    scanf("%s",c);
    n=0;
    for (i = 0; c[i] != '\0'; ++i)
        n = 10 * n + (c[i] -'0');
    printf("%d",n);
}

