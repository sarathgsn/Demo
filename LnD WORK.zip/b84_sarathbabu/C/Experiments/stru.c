#include<stdio.h>

struct s 
{
    int a;
    struct  {
        int c;       
    }p;
}q;
int main(void)
{
//struct b abc;
q.p.c = 10;
   // q.q1.c = 10;
  //  printf("");
    printf("%d", sizeof(q));
}
