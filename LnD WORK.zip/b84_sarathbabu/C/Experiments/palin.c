#include<stdio.h>
int main(void)
{
    int num,j, i;
    scanf("%d",&num);
    for (i=31;i>=0;i--){
        if((num>>i)&1)
          printf("1");
        else printf("0");
    }
printf("\n");
    for (j=0;j<31;j++) {
        if((num>>j)&1)
            printf("1");
        else printf("0");

}
}

