#include<stdio.h>
#include"storage.c"
extern int m;
int main()
{
    printf("%d",m);
}
