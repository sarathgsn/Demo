#include<stdio.h>
#include"header.h"
// static int a=10;
// static int a;
// int a;
// int a=10;
int main()
{
        func();
        printf("sarath\n");
}
