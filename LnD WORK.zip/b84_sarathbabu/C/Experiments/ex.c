#include<stdio.h>
int main(void)
{
    char a[3] ="hello";
    char b[0] = "world";
    printf(a);
    printf(b);
    return 0;
}
