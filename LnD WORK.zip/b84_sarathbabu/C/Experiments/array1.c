#include<stdio.h>
int main(void)
{   int i;
    int a = 2;
    int main[100] = { 1, 2, 3, [10] = 55};
        printf("%d",main[a]);
 
    return 0;
}
