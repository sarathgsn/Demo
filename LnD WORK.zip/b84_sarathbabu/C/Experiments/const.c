#include<stdio.h>
static int static_g_var_init =10;
static int static_g_var_un_init;
const int const_g_var_un_init=10;
 int g_var_init=10;
 int g_var_un_init;
 char *g_str="sarath ";
static int func(int);

int main()
{
      char *l_str="amul";
static int static_l_var_init =10;
static int static_l_var_un_init;
const int const_l_var_un_init=10;
 int l_var_init=10;
 int l_var_un_init;
// printf("%d", a);
// printf("%d", a);
}

static int func(int i)
{
        int func_a=10;
        return 0;
}
