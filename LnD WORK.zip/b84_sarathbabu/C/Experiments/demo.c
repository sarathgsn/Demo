#include<stdio.h>
int main()
{
  signed  int a = -12;
  unsigned int b = 12;
    printf("%d\n",a<<4);
    printf("%d\n",a>>4);
    printf("%d\n",b<<4);
    printf("%d\n",b>>4);
}
