#include<stdio.h>
int main(void)
{
    int a[3] = { 1,2,3};
    printf("%d",a[0] = 1[a]);
    printf("%d",a[1] = 1[a]);
    printf("%d",4[a]);
    return 0;
}
