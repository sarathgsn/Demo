#include<stdio.h>
#define SIZE 100
int len;
char* str_cpy (char*, char*, int);
int main(void)
{
    char sbuf[SIZE],dbuf[SIZE];
    char* char_ptr;
    printf("enter the string sbuf\n");
//    fgets(sbuf,100,stdin);
scanf("%s",sbuf);
    len = strlength(sbuf);
    printf("%d",len);
   char_ptr =  str_cpy (dbuf, sbuf,len);
    printf(" dbuf=%s",dbuf);
    return 0;
}

int strlength (char *sbuf)
 {
     int i;
     for ( i = 0; sbuf[i]; i++);
      
     return i-1;
 } 







char*   str_cpy (char *dbuf, char *sbuf, int len)
{
    while ( *sbuf) {
        *dbuf = *(sbuf + len);
        len-- ;
        dbuf++;
        printf("%s",dbuf);
    } *dbuf = '\0' ;
//    printf("%s",dbuf);
} 



