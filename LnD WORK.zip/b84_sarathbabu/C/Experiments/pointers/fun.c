#include<stdio.h>


int fun(void);

int main(void)
{
    int x = 10;
 //   x = fun();
    printf("%d\n",x+fun());

    return 0;
}

int fun()
{  //int x;
   printf("global");
//  printf("%ds\n", x);

}
