#include<stdio.h>
int y = 10;
//int gavr = y;
int main(void)
{  
    int b = 10;
    int a = 10;
    static int  var = &a ;
 
//   int *const ptr;
//  int *ptr = &var;
//  *ptr = 200;
    printf("%d\n", var);

}
