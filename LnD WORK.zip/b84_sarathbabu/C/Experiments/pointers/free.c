#include<stdio.h>
#include<stdlib.h>

int main(void)
{
    int *ptr = malloc(10);
    free(ptr);
    free(ptr);
    
}
