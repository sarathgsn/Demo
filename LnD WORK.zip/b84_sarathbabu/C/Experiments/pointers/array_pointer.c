#include<stdio.h>

char a[10] = "globaledge";
char *ptr = "globaledge";

int main(void) 
{
    char c = a[5];
    char d = ptr[5];

    return 0;
}
