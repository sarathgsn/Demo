#include<stdio.h>
int main(void)

{
    int *ptr = malloc(1);
    
    printf("%p\n",ptr);
    
    ptr = malloc(100);

    printf("%p\n",ptr+1);
}


