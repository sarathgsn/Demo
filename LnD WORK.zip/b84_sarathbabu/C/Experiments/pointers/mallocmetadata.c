#include<stdio.h>
#include <stdlib.h>
int main(void)
{
    int *ptr = malloc(sizeof(char)*29);
    // ptr ="incccludfgdfgdfgsfsdfsdf";

    printf ("%d\n", *(ptr-1));
}
