#include<stdio.h>

    const static int g;
    const static int s_int = 100;

int main(void)
{
//    const static int loca_int = 10;
}
