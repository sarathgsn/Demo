#include<stdio.h>
int main(void)
{
    int result;
    result = printf(10+"hello");
    printf("%d\n", result);
    return 0;
}
