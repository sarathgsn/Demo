#include<stdio.h>
int fun()
{
    printf("%d\n", max);
}

int main(void)
{ 
  
#define max 100
fun();
   // printf("%d", max);
}
