#include<stdio.h>
int main(void)
{
    int ptr;
    ptr = scanf("%z",&ptr);

    printf("%d\n",ptr);

}
