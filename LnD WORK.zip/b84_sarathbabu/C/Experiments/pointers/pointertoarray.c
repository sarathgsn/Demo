#include<stdio.h>
int main(void)
{
    int arr[5] = { 1,2,3,4,5};
    int (*ptr)[5];
    ptr = arr;
//    printf("value %d\n", (*ptr)[4]);
    printf("ads = %p\n", ptr);
    printf("ads = %p\n", arr);

}
