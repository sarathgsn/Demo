#include<stdio.h>
int main(void)
{
    int arr[2][2] = {{4,8},{3,9}};
    int (*ptr)[4] = arr;
    printf("value = %d\n", (*ptr)[2]);
   printf("value arr[0][1] %d",*(*(arr+1)+1));

} 
