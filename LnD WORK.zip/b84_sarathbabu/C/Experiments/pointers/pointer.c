#include<stdio.h>

int main(void)

{
    int a[10];

    int *a;
}
