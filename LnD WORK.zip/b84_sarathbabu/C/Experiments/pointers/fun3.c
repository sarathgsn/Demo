#include<stdio.h>

int a ;

