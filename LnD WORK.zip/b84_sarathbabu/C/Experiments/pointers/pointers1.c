#include<stdio.h>

int main(void)
{
    char s[] = "global";
    char *ptr = "edgesarath";
    printf("%d", sizeof(s));
    printf("%d", sizeof(*ptr));
    
    return 0;
}
