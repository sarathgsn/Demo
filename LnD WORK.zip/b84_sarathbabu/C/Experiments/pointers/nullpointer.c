#include<stdio.h>
int main(void)
{
    int *ptr = NULL;

//    printf("*ptr= %d", *ptr);
    printf("ads of main = %d\n",sizeof( main));
    printf("ptr = %d\n", ptr);
}
