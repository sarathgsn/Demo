#include<stdio.h>
#define MAX 10
int MAX = 100;
int main(void)
{
    printf  ("MAX %d");
    return 0;
}
