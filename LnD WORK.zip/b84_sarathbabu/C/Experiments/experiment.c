#include<stdio.h>
char* squeeze(char*);
int main(void)
{    

    char sbuf[100], *char_ptr;
    printf("enter the string sbuf\n");
    scanf("%s",sbuf);
  char_ptr = squeeze(sbuf);
   printf("sbuf=%s\n", char_ptr);
    return 0;
}

 char* squeeze(char *sbuf) {
    int i=0; 
    char *ptr = sbuf;
            while (*sbuf !='\0') {
                if ( *sbuf  == *(++ptr )) {
                       printf("%c",*sbuf);
                       sbuf++;
                       ++ptr;
                }else if ( *sbuf !='\0') {
                    i++;
              //  printf("%s",sbuf);
                }





         } //return sbuf;
     }
