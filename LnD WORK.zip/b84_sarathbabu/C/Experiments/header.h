func();
