#include<stdio.h>
#define SIZE 100
char* str_cpy (char*, char*);
int main(void)
{
    char sbuf[SIZE],dbuf[SIZE];
    char *char_ptr;
    printf("enter the string sbuf\n");
    fgets(sbuf,100,stdin);
    char_ptr = str_cpy (dbuf, sbuf);
    printf(" dbuf=%s", char_ptr);
    return 0;
}

char*  str_cpy (char *dbuf, char *sbuf)
{  int i = 0, j= 0; 
    while ( *(sbuf + j) != '\0') {
        *(dbuf + i) = *(sbuf + j);
        i++;
        j++ ;
//        printf("%s",dbuf);
    } *(dbuf + i) = '\0' ;
//    printf("%s",dbuf);
 return dbuf;
}



