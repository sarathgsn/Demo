//#include<stdio.h>
#include "add.h"
int main()
{
    int num1;
    int num2;
    printf("enter the numbers\n");
    scanf("%d",&num1);
    scanf("%d", &num2);
    printf("sum=%d", add(num1, num2));
    return 0;

}
