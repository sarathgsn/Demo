#ifndef _ADD_H
#define _ADD_H
#include<stdio.h>
int add(int, int);
#endif
