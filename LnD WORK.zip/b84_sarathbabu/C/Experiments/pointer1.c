#include<stdio.h>
char *ch_ptr;
int main(void)
{
    char arr[] = "global edge";
    ch_ptr = &arr[0];
    ch_ptr++;
    ch_ptr = ch_ptr + 4;
    *ch_ptr = '0';
    printf("%s",ch_ptr);
    ch_ptr = 0;
    printf("%s",ch_ptr);
     ch_ptr = arr;
     printf("%s",ch_ptr);
    return 0;
}

