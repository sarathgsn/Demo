#include<stdio.h>
#if 0
int main()
{
    char number;
    no = 127;
    printf("%d",number);
}
#endif 



#include<stdio.h>
#if 0
int main()
{
    char number;
    no = 129;
    printf("%d",number);
}
#endif

#include<stdio.h>
#if 0
void main()
{
    int i,n;
    printf("enter a number");
    scanf("%d",&n);
    for (i=31;i>=0;i--) {
         if(n>>i & 1) {
            printf("1");
        }
        else printf("0");
    }
}
#endif 

#include<stdio.h>
#if 0
int main()
{
    int num = 0x99345678;
    char r = num;
    printf("%x",r);
}
#endif



#include<stdio.h>
#if 1
int main()
{
unsigned  int n=16,m;
    m=((1<<n)-1);
    printf("%d",m);
}
#endif 

