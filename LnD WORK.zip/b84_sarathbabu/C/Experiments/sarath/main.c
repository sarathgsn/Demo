#include<stdio.h>
#include"header.h"
void display(int n)
{
	int i;
        for(i=31;i>=0;i--)
        {
                if(n&(1<<i))
                        printf("1");
                else
                        printf("0");
        }
                        printf("\n");
}
int main()
{
	int choice;
	int num,pos1,pos2;
	int num1,num2;
	int n;
	int d;
	int res,res1,res2,res3;
	int c=0,i,pos,dos,opt;
	unsigned int x,p,y;
	printf("enter the choice between 1 to 12: \n");
	scanf("%d",&choice);
	switch(choice)
	{
		/*case 1:
			printf("enter num\n");
			scanf("%d",&num);
			printf("enter pos1:\n");
			scanf("%d",&pos1);
			printf("enter pos2\n");
			scanf("%d",&pos2);
			display(num);
			swap1(num,pos1,pos2);
		case 2:
			printf("enter num1\n");
			scanf("%d",&num1);
			printf("enter num2\n");
			scanf("%d",&num2);
			printf("enter pos1:\n");
			scanf("%d",&pos1);
			printf("enter pos2\n");
			scanf("%d",&pos2);
			display(num1);
			display(num2);
			swap2(num1,num2,pos1,pos2);
		case 3:
			printf("enter num1\n");
			scanf("%d",&num1);
			printf("enter num2\n");
			scanf("%d",&num2);
			printf("enter number of bits\n");
			scanf("%d",&n);
			printf("enter pos1:\n");
			scanf("%d",&pos1);
			printf("enter pos2\n");
			scanf("%d",&pos2);
			display(num1);
			display(num2);
			swap3(num1,num2,n,pos1,pos2)
		/*case 4:
			printf("enter the number\n");
			scanf("%d",&num);
			even_bit_toggle(num);
			odd_bit_toggle(num);
		case 5:
			printf("enter the num\n");
			scanf("%d",&num);
			printf("enter the pos\n");
			scanf("%d",&pos);
			bit_ts(num,pos);
			display(num);
		case 6:
  			printf("enter the number to be rotated\n");
  			scanf("%d",&n);
  			printf("enter the number of times it shud be rotated\n");
  			scanf("%d",&d);
			printf("number before rotation\n");
	  		display(n);
	  		n=leftRotate(n);
  			printf("number after left rotation by 1\n");
  			display(n);
  			n=rightRotate(n);
  			printf("number after right rotation by 1\n");
  			display(n);
  			n=leftRotate_n(n, d);
  			printf("number after left rotation by %d\n",d);
  			display(n);
  			n=rightRotate_n(n, d);
  			printf("number after right rotation by %d\n",d);
  			display(n);
		case 7:
			printf("enter the number\n");
			scanf("%d",&num);
			printf("entered number in binary:\n");
			display(num);
			count_bit_set(num); 
			count_bit_clear(num);
		case 8:
			printf("enter the number\n");
			scanf("%d",&num);
			printf("entered number in binary:\n");
			display(num);
			res=cnt_leading_set_bits(num); 
			printf("number of leading 1s: %d\n",res);
			res1=cnt_trailing_set_bits(num);
			printf("number of trailing 1s: %d\n",res1);
			res2=cnt_leading_cleared_bits(num); 
			printf("number of leading 0s: %d\n",res2);
			res3=cnt_trailing_cleared_bits(num);
			printf("number of trailing 0s: %d\n",res3);*/
		case 9:
    			printf("enter the num...\n");
    			scanf("%d",&num);
    			display(num);
    			printf("enter the option\n");
    			printf("1)big_small\n2)clear right set\n3)clear left set\n4)set right clear\n5)set left clear\n6)set s to d bits\n7)clear s to d bits\n8)toggle s to d bits\n");
   			scanf("%d",&opt);
    			switch(opt)
   			 {
      			  case 1:
          			 printf("enter the num1..\n");
           			 scanf("%d",&num1);
            			 printf("enter the num2...\n");
           			 scanf("%d",&num2);
           			 c=big_small(num1,num2);
           			 if(num1==c)
         			 {
          			        printf("num1 is big..\n");
          		      		printf("num2 is small..\n");
          			 }
          			 else
          			 {
          			      printf("num2 is big..\n");
          			      printf("num1 is small..\n");
         			 }
           	 		 break;
        		case 2:
        			    clear_right_setbit(num,c,i);
        			    display(num);
      				      break;
 	    		   case 3:
			            clear_left_setbit(num,c,i);
 			           display(num);
 			          break;
  			      case 4:
     			       set_right_clearbit(num,c,i);
            display(num);
            break;
        case 5:
            set_left_clearbit(num,c,i);
            display(num);
            break;
        case 6:
            printf("enter the starting pos...\n");
            scanf("%d",&pos);
            printf("enter the destination dos..\n");
            scanf("%d",&dos);
            set_s_and_d(num,pos,dos);
            display(num);
            break;
        case 7:
            printf("enter the starting pos...\n");
            scanf("%d",&pos);
            printf("enter the destination dos..\n");
            scanf("%d",&dos);
            clear_s_and_d(num,pos,dos);
            display(num);
            break;
        case 8:
            printf("enter the starting pos....\n");
            scanf("%d",&pos);
            printf("enter the destination dos...\n");
            scanf("%d",&dos);
            toggle_s_and_d(num,pos,dos);
            display(num);
            break;
        default:
            printf("enter the proper option...\n");
    }
	
	
	/*case 10:	
        printf("enter the x\n");
        scanf("%d",&x);
        printf("enter the pos to x\n");
        scanf("%d",&p);
        printf("enter the num of bits\n");
        scanf("%d",&n);
        printf("enter the y\n");
        scanf("%d",&y);
	display(x);
	display(y);
  	printf("%u",setbits((unsigned)12,3,2,(unsigned)57));
    	res=setbits(x,p,n,y);
	display(res);
	
	case 11:
   	 printf("enter the x\n");
        scanf("%d",&x);
        printf("enter the pos to x\n");
        scanf("%d",&p);
        printf("enter the num of bits\n");
        scanf("%d",&n);

	display(x);
    	res=invert(x,p,n);
	display(res);
	
	case 12:	
        printf("enter the x\n");
        scanf("%d",&x);
        printf("enter the pos to x\n");
        scanf("%d",&p);
        printf("enter the num of bits\n");
        scanf("%d",&n);

	display(x);
    	res=getbits(x,p,n);
	display(res);
	
	default:
            printf("enter the proper option...\n");*/
} 	

}

