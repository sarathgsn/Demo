unsigned getbits(unsigned x, int p, int n)
{
     return   (x>>(n-(p+1)) & ~(~0 << n));
}

