void swap3(int n1,int n2,int n,int p1,int p2)
{
        int src,dest,i,j;
	for(i=p1;i<=n;i++)
	{
		for(j=p2;j<=n;j++)
		{
		
        		src=n1&(1<<p1);
	   	     	dest=n2&(1<<p2);
			if(src == dest)
			{	
				continue;
			}
			else
			{	
				n2=n2^(1<<p2);
			}
		}
	}
				display(n2);
}

