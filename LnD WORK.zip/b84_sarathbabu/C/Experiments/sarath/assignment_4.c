#include"header.h"
int even_bit_toggle(int n)
{
	int i;
	for(i=0;i<=SIZE;i++)
	{
		if(i%2==0)
			n=n^(1<<i);
	}
	printf("even bit toggle:\n");
	display(n);
}

int odd_bit_toggle(int n)
{
	int i;
	for(i=0;i<=SIZE;i++)
	{
		if(i%2!=0)
			n=n^(1<<i);
	}
	printf("even bit toggle:\n");
	display(n);
}

