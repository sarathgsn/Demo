void swap2(int n1,int n2,int p1,int p2)
{
        int src,dest;
        src=n1&(1<<p1);
        dest=n2&(1<<p2);
	if(src == dest)
	{	
		display(src);
		display(dest);
	}
	else
	{	
		n1=n1^(1<<p1);
		n2=n2^(1<<p2);
		display(n1);
		display(n2);
	}
}


