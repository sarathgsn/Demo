/////////////////////////////////////////////////// ASSIGNMENT_1
#include<stdio.h>
#define SIZE (((sizeof(int))*8)-1) 

void display(int n);


void swap1(int n,int p1,int p2);

/////////////////////////////////////////////////// ASSIGNMENT_2

void swap2(int n1,int n2,int p1,int p2);


/////////////////////////////////////////////////// ASSIGNMENT_3

void swap3(int n1,int n2,int n,int p1,int p2);


/////////////////////////////////////////////////// ASSIGNMENT_4

int even_bit_toggle(int n);

int odd_bit_toggle(int n);

/////////////////////////////////////////////////// ASSIGNMENT_5
#define bit_ts(num, pos) ((num&(1<<pos))?(printf("no need to set\n")):((num)|=(1<<pos)));

/////////////////////////////////////////////////// ASSIGNMENT_6
#define INT_BITS 31
 
/*Function to left rotate n by d bits*/
int leftRotate_n(int n, unsigned int d);
 
/*Function to right rotate n by d bits*/
int rightRotate_n(int n, unsigned int d);

/*Function to left rotate n by 1 bits*/
int leftRotate(int n);
 
/*Function to right rotate n by 1 bits*/
int rightRotate(int n);


/////////////////////////////////////////////////// ASSIGNMENT_7
int count_bit_set(int num);

int count_bit_clear(int num);


/////////////////////////////////////////////////// ASSIGNMENT_8
int cnt_leading_set_bits(int num);
int cnt_trailing_set_bits(int num);

int cnt_leading_cleared_bits(int num);

int cnt_trailing_cleared_bits(int num);

/////////////////////////////////////////////////// ASSIGNMENT_9

#define MIN 0
#define MAX sizeof(int)*8-1

#define big_small(num1,num2) ((num1-num2)>>MAX)&1?num2:num1;
#define clear_right_setbit(num,c,i) for(i=MIN,c=0;i<MAX,c<1;i++)\
{\
    if((num&1<<i)==1)\
    {\
        num=num^(1<<i);\
        c++;\
    }\
}
#define clear_left_setbit(num,c,i) for(i=MAX,c=0;i>=MIN,c<1;i--)\
{\
    if((num&1<<i)!=0)\
    {\
        num=num^(1<<i);\
        c++;\
    }\
}
#define set_right_clearbit(num,c,i) for(i=MIN,c=0;i<MAX,c<1;i++)\
{\
    if((num&1<<i)==0)\
    {\
        num=num^(1<<i);\
        c++;\
    }\
}
#define set_left_clearbit(num,c,i) for(i=MAX,c=0;i>=MIN,c<1;i++)\
{\
    if((num&1<<i)==0)\
    {\
        num=num^(1<<i);\
        c++;\
    }\
}
#define set_s_and_d(num,pos,dos) for(i=MIN;i<=MAX;i++)\
{\
    if(i==pos)\
    {\
        for(pos=i;pos<=dos;pos++)\
        {\
            num=num|(1<<pos);\
        }\
        i=pos;\
    }\
    num=num&~(1<<i);\
}
#define clear_s_and_d(num,pos,dos) for(i=MIN;i<=MAX;i++)\
{\
    if(i==pos)\
    {\
        for(pos=i;pos<=dos;pos++)\
        {\
            num=num&~(1<<pos);\
        }\
        i=pos;\
    }\
    num=num|(1<<i);\
}
#define toggle_s_and_d(num,pos,dos) for(i=MIN;i<=MAX;i++)\
{\
    if(i==pos)\
    {\
        for(pos=i;pos<=dos;pos++)\
        {\
            num=num^(1<<pos);\
        }\
        i=pos;\
    }\
}\

/////////////////////////////////////////////////// ASSIGNMENT_11
unsigned invert(unsigned x, int p, int n);

/////////////////////////////////////////////////// ASSIGNMENT_12
unsigned getbits(unsigned x, int p, int n);

