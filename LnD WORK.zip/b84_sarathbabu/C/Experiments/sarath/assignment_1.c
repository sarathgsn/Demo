
void display(int n)
{
	int i;
        for(i=31;i>=0;i--)
        {
                if((n>>i)&1)
                        printf("1");
                else
                        printf("0");
        }
                        printf("\n");
}

void swap1(int n,int p1,int p2)
{
        int src,dest;
        src=n&(1<<p1);
        dest=n&(1<<p2);
	if(src == dest)
	{	
		display(src);
	}
	else
	{	
		n=n^(1<<p1);
		n=n^(1<<p2);
		display(n);
	}
}



