#include"header.h"
int count_bit_set(int num)
{
	int i,count1;
	for(i=0;i<=INT_BITS;i++)
        {
                if((num>>i&1) == 1)
                        count1++;
        }
        printf("number of 1s: %d\n",count1);

}

int count_bit_clear(int num)
{
	int i,count0;
        for(i=0;i<=INT_BITS;i++)
        {
                if((num>>i&1) != 1)
                        count0++;
        }
        printf("number of 0s: %d\n",count0);
}
