#include"header.h"
int cnt_leading_set_bits(int num)
{
	int i,count1; 
        for(i=SIZE;i>=0;i--)
        {
		int i,count1;
                if((num>>i&1) != 0)
		{
                count1++;
		}
		else
		return count1;
        }

}
int cnt_trailing_set_bits(int num)
{
	int i,count1;
        for(i=0;i<SIZE;i++)
        {
                if(((num>>i)&1) != 0)
		{
                count1++;
		}
                else
                return count1;
        }

}

int cnt_leading_cleared_bits(int num)
{
	int i,count0;
        for(i=SIZE;i>=0;i--)
        {
                if((num&(i<<1)) == 0)
		{
                count0++;
		}
		else
		return count0;
        }

}
int cnt_trailing_cleared_bits(int num)
{
	int i,count0;
        for(i=0;i<=SIZE;i++)
        {
                if((num&(1<<i)) == 0)
                count0++;
                else
                return count0;
        }

}
