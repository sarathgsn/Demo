#include<stdio.h>
extern a;
int print(void)
{
printf("%d",a);
}
