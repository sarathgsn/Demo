#include<stdio.h>
int main(void)
{
     int a,b = 10;

       a=&b;
       int  *p = &a;
       printf("%p\n",a);
       printf("%d\n",p);
            
 return 0;
}
