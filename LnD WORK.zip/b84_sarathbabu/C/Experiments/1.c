#include<stdio.h>
int main(void)
{  
    int var = 040;
    printf("%d %o %x\n", var, var, var);
//    printf("printf("hello world")");

return 0;
}
