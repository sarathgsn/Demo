func(){
       int a;
}
