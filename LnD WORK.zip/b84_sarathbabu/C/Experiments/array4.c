#include<stdio.h>
int main(void)
{
    int b = 10;
    int a[3] = {1,2,3};
     a[3] = 12;
     printf("a is =%d",a[3]);
     return 0;
}
