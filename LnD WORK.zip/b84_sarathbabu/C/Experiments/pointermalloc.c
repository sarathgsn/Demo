#include<stdio.h>
#include<stdlib.h>


int main() 
{   int var = 100;
//    char p['hello'] = { 'a', 'b', 'c'};
//    printf("%c", p['hello']);
    printf( "\"%d\" hello", var);
    return 0;
}
