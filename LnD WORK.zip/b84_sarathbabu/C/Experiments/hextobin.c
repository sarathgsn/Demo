 #include<stdio.h>
int main()
{
    int number = 0x1234567;
    int i;
    char c = number ;
   printf("%d",(char*)&c);
   for (i=7;i>=0;i--){
        if ((c>>i)&1){
            printf("1");
        }
            else printf("0"); 
    }
//  printf("%u",(char*)p);

}
