#include<stdio.h>
void main()
{
int a=3,b=5;
int c;
c=a+b;
printf("%d",c);
}
