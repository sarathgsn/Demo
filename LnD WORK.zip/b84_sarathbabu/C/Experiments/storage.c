#include<stdio.h>
int m=10;
static int c_sta=10;
int main()
{
    int a_auto = 12;
    register int a_reg=0;
    for (a_reg =1; a_reg<=1;a_reg++) {
        int b_auto =18;
        register b_reg =20;
        static b_sta =22;
    printf("%d%d%d",b_auto,b_reg,b_sta);
    }
    printf("%d%d%d",a_auto,a_reg,c_sta);
 }
