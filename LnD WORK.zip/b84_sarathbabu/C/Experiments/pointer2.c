#include<stdio.h>
int main(void)
{
    char *ptr = "global edge";
    printf("%s",ptr );
    return 0;
}
