#include<stdio.h>
int main(void)
{
    char a[10][5] = { "hi","hello","morning"};
    printf("%s", a[2]);

    return 0;
}
