#include<stdio.h>
#define MAX(x)  printf(#x "hai ")
    
 



int main(void)
{ 
    int y = 10;
    MAX(h#<include<stdio.h>a);
//    printf("resulr =%d\n", MAX(0));
}

