#include<stdio.h>
#define get(s) #s
int main(void)

  {
      printf("%s\n", get(main));
  }
