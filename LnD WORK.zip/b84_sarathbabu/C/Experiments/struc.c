#include<stdio.h>
int fun(void);
int main(void)
{

int int = 10;
x = fun();
printf("%d\n", fun());

 }

int fun()
{
    printf("global");
}
