#include<stdio.h>

int a = 10;


int main(void)
{
    int a = 20;
    {
           printf("%d\n", a);

//        int a =  30;
        {
            int a = 40;
        }
        printf("%d\n",a);
    }
}
