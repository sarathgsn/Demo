#include<stdio.h>
/*int main(void)
{   int ch;
    int a = 5, b = 10;
    FILE *fp1;
    fp1 = fopen ("file.txt", "r");
    fscanf(fp1,"%d %d\n",&a ,&b);
//   ch = fread(fp1);
   printf("%d",ch);
//   put(ch, stdout);
     printf("Written to file\n");
 return 0 ;
}
*/
