#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include"header.h"
int upper()
{
    FILE *fp1,*fp2;
    char ch,cname[20],d;
    fp1=fopen(cname,"w");
    printf("enter file name");
    scanf("%s",cname);
    fp1=fopen(cname,"r");
    if(fp1==NULL)
    {
        printf("sorry to open file");
        exit (1);
    }
    while(ch!=EOF)
{
   if(ch>='A'&&ch<='Z'){
       d=ch+32;
     printf("%c ",d);
   }
   else
       printf("%c",ch);
   
   ch=fgetc(fp1);
}

   fclose(fp1);
return 0;
}
