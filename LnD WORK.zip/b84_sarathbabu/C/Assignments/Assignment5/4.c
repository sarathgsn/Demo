#include<stdio.h>
int count()
{
 FILE *p;
 char ch;
 int w=0,c=0;
p=fopen("/home/sarath/b84_sarath/C/Assignments/Assignment5/file.txt","r");
if(p==NULL)
  {
 printf("file not found");
 }
    else
 {
     ch=fgetc(p);
   while(ch!=EOF)
{
     printf("%c",ch);
    if(ch>='A'&&ch<='Z'||ch>='a'&&ch<='z')
  {
  w++;
  }
    else {
    c++;
    }
      ch=fgetc(p);
  }
   printf("\nWords in a file are=%d",w);
   printf("\nother char is %d",c);
}
  fclose(p);
   return 0;
    }
