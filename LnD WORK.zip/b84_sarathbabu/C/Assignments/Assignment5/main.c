#include <stdio.h>
#include"header.h"
int main(void)
{
    int choice;
    printf("enter 1 for upper case conversion\n ");
    printf("enter 2 for search string\n ");
    printf("enter 3 for remove coment\n ");
    printf("entr 4 for counting word\n ");
    printf("enter 5 for write struct\n ");
    printf("enter 6 for read struct\n ");
    scanf ("%d", &choice);
    switch (choice)
    {
        case 1:
            upper();
            break;
        case 2:
            search_str();
            break;
        case 3:
            rem_cmnt();
            break;
        case 4:
           count();
            break;
        case 5:
            write_struct();
            break;
        case 6:
            read_struct();
            break;
        default:
            printf("Invalid Options ");
            break;
    }

return 0;
}
