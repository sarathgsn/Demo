
int upper();
int search_str();
int rem_cmnt();
int count();
int write_struct();
int read_struct();

