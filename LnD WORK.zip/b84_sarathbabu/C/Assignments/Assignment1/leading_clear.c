#include"header.h"

int leading_set_bits (int num)
{  int i, one;
 for (i = sizeof(int)*8 - 1; i >= 1; i--) {
    if(num >> i & 1)
        ++one;
    else break;   
    }
 return one;

}

int leading_clear_bits (int num)
{
    int i, zero;
    for (i = sizeof(int)*8 - 1; i >= 1; i--) {
        if (num >> i & 1)
            break;
        else ++zero;
    }
    return zero;
}

int trailing_set_bits  (int num)
{
    int i, one1;
    for (i = 0; i <= sizeof(int)*8 - 1; i++) {
        if (num >> i & 1)
           ++ one1;
        else break;
    }
    return one1;
}

int trailing_clear_bits (int num)
{
    int i, zero1;
    for (i = 0; i <= sizeof(int)*8 - 1; i++) {
        if (num >>i &1)
            break;
        else ++zero1;
    }
    return zero1;
}
