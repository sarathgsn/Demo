#include"header.h"
#define bit_set (num, pos) num | (1 << pos)

