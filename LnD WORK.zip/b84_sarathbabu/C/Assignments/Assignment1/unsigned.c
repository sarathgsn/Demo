#include"header.h"
int  unsigned_int_left_rotate_n_bits (int num, int n)
     {
     return (num << n) | (num >> (sizeof(int)*8 - n));
     }

int unsigned_int_right_rotate_n_bits (int num, int n)
{
    return (num  >> n) | (num << (sizeof(int)*8 - n));
}

