#include<stdio.h>
#include"header.h"
#include"switch.c"
int a, b, c, d, snum, dnum, s, n, m, p, d, num;
int main(void)
{
    int choice;
    int result;
printf ("Assignment1\n");
printf ("1.Swap the number betwwen s and d\n");
printf ("2.swap two numbers between two bit positions\n");
printf ("3.bit copy\n");
printf ("4.Toggle the even bits\n");
printf ("5.Toggle the odd bits\n");
printf ("6.Left rotate the number\n");
printf ("7.Right rotate the number\n");
printf ("8.left rotate n bits in a number\n");
printf ("9.right rotate n bits in a number\n");
printf ("10.leadeing set bits\n");
printf ("11.leading clear bits\n");
printf ("12.trailing set bits\n");
printf ("13.trailing clear bits\n");
printf ("14. setbits\n");
printf ("15. invert bits\n");
printf("16. macro set bit position\n");


printf ("enter your choice\n");
scanf ("%d", &choice);
result = options(choice);   //invoking the  function 
printf("%d",result);


return 0;
}

 

