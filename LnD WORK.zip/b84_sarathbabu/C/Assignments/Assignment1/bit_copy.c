#include"header.h"
int bit_copy (int snum, int dnum, int n, int s, int d) {
   int i,j,m,p;
  for (i = s, j = d; n--; i--, j--) {
     m = snum >> i & 1;
     p = dnum >> j & 1;
    if (m != n) {
      dnum = dnum ^ (1 << j);
    }
  } 
return dnum;
}
