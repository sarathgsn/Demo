#include"header.h"
#define MIN 0
#define MAX sizeof(int)*8-1

#define big_small(num1,num2) ((num1-num2)>>MAX)&1?num2:num1;
#define clear_right_setbit(num,c,i) for(i=MIN,c=0;i<MAX,c<1;i++)\
{\
    if((num&1<<i)==1)\
    {\
        num=num^(1<<i);\
        c++;\
    }\
}
#define clear_left_setbit(num,c,i) for(i=MAX,c=0;i>=MIN,c<1;i--)\
{\
    if((num&1<<i)!=0)\
    {\
        num=num^(1<<i);\
        c++;\
    }\
}
#define set_right_clearbit(num,c,i) for(i=MIN,c=0;i<MAX,c<1;i++)\
{\
    if((num&1<<i)==0)\
    {\
        num=num^(1<<i);\
        c++;\
    }\
}
#define set_left_clearbit(num,c,i) for(i=MAX,c=0;i>=MIN,c<1;i++)\
{\
    if((num&1<<i)==0)\
    {\
        num=num^(1<<i);\
        c++;\
    }\
}
#define set_s_and_d(num,pos,dos) for(i=MIN;i<=MAX;i++)\
{\
    if(i==pos)\
    {\
        for(pos=i;pos<=dos;pos++)\
        {\
            num=num|(1<<pos);\
        }\
        i=pos;\
    }\
    num=num&~(1<<i);\
}
#define clear_s_and_d(num,pos,dos) for(i=MIN;i<=MAX;i++)\
{\
    if(i==pos)\
    {\
        for(pos=i;pos<=dos;pos++)\
        {\
            num=num&~(1<<pos);\
        }\
        i=pos;\
    }\
    num=num|(1<<i);\
}
#define toggle_s_and_d(num,pos,dos) for(i=MIN;i<=MAX;i++)\
{\
    if(i==pos)\
    {\
        for(pos=i;pos<=dos;pos++)\
        {\
            num=num^(1<<pos);\
        }\
        i=pos;\
    }\
}\
