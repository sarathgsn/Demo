
#include"header.h"
int even_bit_toggle (int num)
{
    int  i;
    for ( i = 0; i < sizeof(int)*8;)  {
        num = num ^ (1 << i);
         i+=2;
    }
    return num;
}


int odd_bit_toggle (int num)
{
    int i;
    for(i = 1; i < sizeof(int)*8; i+=2) {
        num = num ^ (1 << i);
    }
    return num;
}
