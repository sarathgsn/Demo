#include<stdio.h>
int main(void)
{   
    int num1, i;
    int num = 12.1;
//    scanf("%d",&num);
//    num1 = num << 2;
    for (i=31;i>=0;i--){
        if((num>>i)&1)
          printf("1");
        else printf("0");
    }
}

