#include"header.h"
int invert_bit(int num, int p, int n)
{
    int i, j;
    for(i = p;i>0 ;i--){
        num = num ^ (1 << i);
//        printf("%d",num);
    }
    return num;
}
