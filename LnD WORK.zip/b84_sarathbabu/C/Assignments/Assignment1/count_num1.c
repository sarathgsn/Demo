#include"header.h"

int count_bit_set (int num)
{
    int i, one;
    for (i = sizeof(int)*8; i > 0; i--) {
        if (( a >> i) & 1)
            ++one;
    }
        return one;
}

 int count_bit_clear (int num)
{
    int j, zeros;
    for(j = sizeof(int)*8; j > 0; j--) {
        if ((b >> j) & 1)
          {
              continue;
          } else ++zeros; 
    }
    return zeros;
}


