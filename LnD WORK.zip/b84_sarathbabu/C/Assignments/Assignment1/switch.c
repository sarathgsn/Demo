#include<stdio.h>
#include"header.h"
int a, b, c, d, snum, dnum, s, n, m, p, d, num, x, y;
int result;
int options(int choice)
{  



    switch(choice)
    {
    case 1: printf("enter the number along with  bit positions  s ,d\n");
            scanf("%d%d%d", &n, &s, &d);
            result= bit_swap(n, s, d);  //invoking the function
            return result;
            break;
    case 2: printf("enter the snum ,s,dnum,d\n");
             scanf("%d%d%d%d",&snum,&s,&dnum,&d);
            result =  bit_swap1 (snum, s, dnum, d);
            return result;
    case 3: printf("enter the snum ,dnum, n ,s ,d");
            scanf("%d%d%d%d%d",&snum, &dnum, &n, &s, &d);
            result = bit_copy(snum, dnum, n, s, d);
            return result;
    case 4: printf("enter the number\n");
            scanf("%d",&num);
            result = even_bit_toggle(num);
            return result;
    case 5: printf("enter the number\n");
            scanf("%d",&num);
            result = odd_bit_toggle(num);
            return result;
    case 6: printf("enter the number\n");
            scanf("%d",&num);
            result = unsigned_bit_left_rotate(num);
            return result;
    case 7: printf("enter the number\n");
            scanf("%d",&num);
            result = unsigned_bit_right_rotate(num);
            return result;
    case 8: printf("enter the number along with n\n");
            scanf("%d%d",&num, &n);
            result = unsigned_int_left_rotate_n_bits (num, n);
            return result;
    case 9: printf("enter the number along with n\n");
            scanf("%d%d",&num, &n);
            result = unsigned_int_right_rotate_n_bits(num, n);
            return result;
   case 10: printf("enter the number\n");
             scanf("%d",&num);
             result = leading_set_bits(num);
             return result;
    case 11: printf("enter the number\n");
             scanf("%d",&num);
             result = leading_clear_bits(num);
             return result;
    case 12: printf("enter the number\n");
             scanf("%d",&num);
             result = trailing_set_bits(num);
             return result;
    case 13: printf("enter the number\n");
             scanf("%d", &num);
             result = trailing_clear_bits(num);
             return result;
    case 14: printf("enter the x,p,n,\n");
             scanf("%d%d%d",&x,&p,&n);
             result = getbits(x, p, n);
             return result;
    case 15: printf("enter the num p n\n");
             scanf("%d%d%d", &num, &p, &n);
             result = invert_bit(num, p, n);
             return result;

   case 16:  printf("enter the num and pos\n");
             scanf("%d%d", &num, &pos);
             printf("result is=%d", bit_set(num, pos));
}
}
