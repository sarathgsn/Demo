#include"header.h"
#include<stdio.h>
int bit_swap1 (int snum, int s, int dnum, int d)
{
    if  (snum & (1 << s ) ^ dnum & (1 << d)) {
       snum = snum ^ (1 << s);
       dnum = dnum ^ (1 << d);
       printf ("%d%d", snum, dnum);
    } else printf ("%d%d", snum, dnum);
} 
