
#include"header.h"
int bit_swap (int n, int s, int d) 
{
    if ((( n >> s) & 1) ^ (( n >> d) & 1)) {
            return n = n ^ (1 << s | 1 << d);
                    }
                    else return n;
}
