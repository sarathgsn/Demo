#include"header.h"

int unsigned_bit_left_rotate (int num)
{
    return (num << 1 | num >> (sizeof(int)*8 - 1));
}
 
int unsigned_bit_right_rotate (int num)
{
    return ( num >> 1 | num >> (sizeof(int)*8 - 1));
}

