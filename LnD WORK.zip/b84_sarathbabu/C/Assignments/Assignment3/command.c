#include<stdio.h>
int myatoi (char*);
 int add(int, int); // declaration of add  function
int sub(int, int);  // declaration of sub function
int mul(int, int);  // declaration of mul function
int div(int, int);  //  declration of div function
int main(int argc, char *argv[]) // command line arguments
{       
    
       int  num1;
       int  num2;
       int result;
    num1  = myatoi (argv[2]); //invoking ATOI function
    printf("%d\n", num1);
    num2 = myatoi (argv[3]);
    printf ("%d\n", num2);
int (*fun_ptr)(int, int); 
int (*fun_ptr1_arr[4])(int, int);
switch (argv[1][0])
{
    
    case '+':  fun_ptr1_arr[1] = &add;
              result = (*fun_ptr1_arr[1])(num1, num2);
            printf("output of add=%d", result);
            break;
    case '-': fun_ptr1_arr[2] = &sub;
              result = (*fun_ptr1_arr[2])(num1, num2);
            printf("%d",result);
              break;
    case '*':  fun_ptr1_arr[3] = &mul;
              result = (*fun_ptr1_arr[3])(num1, num2);
             printf("%d",result);
             break;
    case '/': fun_ptr1_arr[4] = &div; 
             result = (*fun_ptr1_arr[4])(num1, num2);
             printf("%d",result); 
}   
    return 0;
}







int myatoi (char *argv) {
    int res = 0;
    int i;
    for( i = 0; argv[i] !='\0'; i++) 
        res = res * 10 + (argv[i] - '0') ;
    return res;
}


int add(int num1, int num2) {
    return (num1 + num2);
}

int sub(int num1, int num2) {
    return (num1 - num2);
}

int mul(int num1, int num2) {
    return (num1 * num2);
}

int div(int num1, int num2) {
    return (num1 / num2);
}
