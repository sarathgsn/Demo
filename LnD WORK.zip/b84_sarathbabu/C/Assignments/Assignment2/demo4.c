#include"header2.h"
 char* char_snappend ( char *sbuf, char *dbuf, int num, int len) {
           int j;
         for(j=0; j<num; j++) { 
             *(dbuf + len ) = *(sbuf + j);
             len++;
             }
             dbuf[len] = '\0';

            return dbuf;
 }




