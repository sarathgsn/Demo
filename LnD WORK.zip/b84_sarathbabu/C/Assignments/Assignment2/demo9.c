#include"header2.h"
int   palindrome (char *sbuf, int len)
{    int count; 
    int len1 = len/2;
    int i;    
    
    while(i <= len1) { 
  //    for (i = 0; i <= len/2; i++) {
          if ( *(sbuf + i) == *(sbuf + len-1 )) {
     //    printf("hi");
              len--;
             ++count;
            
          }else
              i++;
    }return count;

}
     



