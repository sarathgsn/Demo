#include "header2.h"
#include<stdio.h>
int options(int choice)
{   char sbuf[100];
    char dbuf[100];
    char *result;
    int num;
    int len;
    int res;
    char  c ,str[100],str2[100];
    int pos, count;
    char org[100];
    switch(choice)
    {

        case 1: printf("enter the string sbuf\n");
                scanf("%s", sbuf); 
                result = str_cpy(sbuf, dbuf);
                printf("%s",result);
                break;

       case 2: printf("enter the strings sbuf ,dbuf,number of characters to be copy\n");
                scanf("%s%s%d",sbuf, dbuf, &num);
                result = strn_cpy (sbuf, dbuf, num);
                printf("sbuf=%s",result);
                     break;
         case 3: printf("enter the strings sbuf and c\n");
                 scanf("%s%c", sbuf, &c);
                 result = char_instr(sbuf, c);
                 printf("sbuf=%s",result);
                  break;
         case 4: printf("enter the string sbuf and dbuf\n");
                 scanf("%s%s", sbuf, dbuf);
                 num = strlength(sbuf);
                 result = char_sappend(sbuf, dbuf, num);
                 printf("sbuf=%s", result);
                     break;
         case 5: printf("enter the strings sbuf dbuf and number of chracters\n");
                 scanf("%s%s%d", sbuf, dbuf, &num);
                 len = strlength(dbuf);
                 result = char_snappend(sbuf, dbuf, num, len);
                 printf("%s\n",result);
                   break;
        case 6: printf("enter the two strings str1 and str2\n");
                scanf("%s%s", sbuf, dbuf);
                res = str_cmp(sbuf, dbuf);
                printf("%d",res);
                   break;
        case 7: printf("enter the two strings sbuf and dbuf\n");
                scanf("%s%s", sbuf, dbuf);
               res = strcase_cmp(sbuf, dbuf);
                printf("%d",res);
                  break;
         case 8: printf("enter the two strings sbuf and dbuf\n");
                 scanf("%s%s", sbuf, dbuf);
                 res = char_strspn(sbuf, dbuf);
                 printf("%d",res);
                 break;
                     
        case 9: printf("enter the string and delimiter\n");
                scanf("%s%s" ,sbuf, dbuf);
                num = strlength(sbuf);
                result = str_tok(sbuf, dbuf, num);

       case 10: printf("enter the string\n");
                scanf("%s",sbuf);
                num = strlength(sbuf);
                res = palindrome(sbuf, num);
                if ( res >= num/2)
                 printf("given string is palindrome\n");
                else printf("given string is not a palindroma\n");
                break;
       case 11: printf("enter the string\n");
                scanf("%s%s", str, str2);
                result = reverse(str, str2);
               printf("%s",result); 
                  break;
      case 12 : printf("enter the string\n");
               scanf("%s",sbuf);
               result = squeeze(sbuf);
              printf("%s",result); 
               break;
      case 14 : printf("enter the two strings sbuf and dbuf\n");
                scanf("%s%s", sbuf, dbuf);
                result = remsstr (sbuf, dbuf, org);
                printf("%s",result);
                  break;
      case 15: printf("enter the string sbuf and character c and position\n");
               scanf("%s%c%d", sbuf, &c, &pos);
               result = insertchar(sbuf, c, pos,org);
               printf("%s",result);

   
    }
}
