#include "header2.h"

char* char_instr(char *sbuf, char c) 
{
    while ( *sbuf != '\0'){
        if ( *sbuf == c) 
            return sbuf;
         sbuf++;
    }
 }


