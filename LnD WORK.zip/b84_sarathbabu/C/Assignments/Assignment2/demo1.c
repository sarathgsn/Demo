#include "header2.h"
char*  strn_cpy(char *sbuf, char *dbuf, int  num)
{   int   i = num;
    for (i=0; i < num; i++) {
        if ( *sbuf != '\0') {
        *dbuf = *sbuf;
        sbuf++ ;
        dbuf++ ;
        }
    } *dbuf = '\0' ;
return dbuf;
}



