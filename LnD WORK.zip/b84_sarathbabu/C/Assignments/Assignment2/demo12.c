#include<stdio.h>
#define SIZE 100
// str_cpy (char, char);
/*int main(void)
{
    char sbuf[SIZE],dbuf[SIZE];
    printf("enter the string sbuf\n");
    fgets(sbuf,100,stdin);
    str_cpy (dbuf, sbuf);
    printf("sbuf=%s\n dbuf=%s", sbuf ,dbuf);
    return 0;
}
*/
int strlength (char *sbuf)
 {
     int i;
     for ( i = 0; sbuf[i]; i++);
      
     return i-1;
 } 







   str_cpy1 (char *dbuf, char *sbuf)
{
    while ( *sbuf != '\0') {
        *dbuf = *sbuf;
        sbuf++ ;
        dbuf++ ;
    } *dbuf = '\0' ;

}



