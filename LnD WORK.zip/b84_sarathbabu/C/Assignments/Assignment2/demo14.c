#include"header2.h"
 char* insertchar(char *sbuf, char c, int pos, char *org) { 
//                char org[100];
                int i=0;
               
         while ( *sbuf != '\0'){
       

              if ( i == pos) {
                    org[i]= c;
                    i++;
//                    printf("%c",*org);
              }else {
                  org[i] = *sbuf;
             // printf("%c",org[i]);
              i++;
              sbuf++;}
              
    }return org; 
 }


