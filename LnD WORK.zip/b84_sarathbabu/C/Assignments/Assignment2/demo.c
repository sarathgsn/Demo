#include"header2.h"
char*  str_cpy (char *sbuf, char *dbuf)
{      int i = 0, j = 0;
    while ( *(sbuf + j) != '\0') {
        *(dbuf + i) = *(sbuf + j);
        i++ ;
        j++ ;
    } *(dbuf + i) = '\0' ;
 return dbuf;
}



