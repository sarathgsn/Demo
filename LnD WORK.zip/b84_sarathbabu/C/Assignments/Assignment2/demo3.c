#include "header2.h"
char* char_sappend(char *sbuf, char *dbuf, int num) 
{
     int j;

     for (j = 1; *dbuf != '\0'; j++) {
        *(sbuf+num) = *dbuf;
        num++;
        dbuf++;
     }
     
     *(sbuf+num) = '\0';

     return sbuf;
 }




