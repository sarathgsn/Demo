#include"header2.h"
 char* remsstr (char *sbuf, char *dbuf, char* org)
{  //     char org[100];
     
                int k = 0;
while (*sbuf != '\0') {
    if ( *sbuf  == *dbuf ){ 
            sbuf++;
           dbuf++;
//printf("%c",*sbuf);
           } else 
           { //printf("%c",*sbuf);
             org[k] = *sbuf;
           //  printf("%c",org[k]);
             k++;
               sbuf++;}
 } org[k] = '\0';
  return org;
}
