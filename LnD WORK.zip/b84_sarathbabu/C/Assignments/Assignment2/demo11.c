#include"header2.h"
char *squeeze(char *str)
{ 
    int i,j;
    int l1 = strlength(str);
    for(i=0; i<l1; i++)
    {
        if(*(str+i) == *(str+(i+1))){
            for(j=i; j<l1; j++)
            {
                *(str+j) = *(str+(j+1));
            }
           i--;
           l1--;
        }
    }
    *(str+i) = '\0';
 return str;   
}


