#include<stdio.h>
#include"header2.h"
int main(void)
{ 
    int choice;
   printf("enter the choice\n");
   printf("1.for string copy\n");
   printf("2.for string N copy\n");
   printf("3.Address of first accurence of character\n");
   printf("4.string append\n");
   printf("5.string N append\n");
   printf("6.string compare\n");
   printf("7.string compare by ignoring CASE\n");
   printf("8.sub string count\n");
   printf("9.string tokenizer\n");
   printf("10.palindrome\n");
   printf("11.string reverse\n");
   printf("12.string squeeze\n");
   printf("14.removing substring\n");
   printf("15.insertchar to string\n");
 



   scanf("%d",&choice);
   options(choice);   

return 0;
}
