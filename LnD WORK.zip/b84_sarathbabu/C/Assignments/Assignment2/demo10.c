#include"header2.h"
char *reverse(char *str, char *str2)
 {  
//     char str2[100];
     int i=0;
     int j=strlength(str);
     j = j-1;
     while(j >= 0){
     *(str2+i) = *(str+j);
         i++;
         j--;
     }
     str2[i] = '\0';

     return str2;

 }


