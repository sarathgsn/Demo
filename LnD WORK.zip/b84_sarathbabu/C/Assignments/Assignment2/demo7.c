#include"header2.h"
  

 int char_strspn( char *sbuf, char*dbuf) {
           
     int j;
    int count = 0;
             for (j=0; *sbuf != '\0' ; j++) {
                if( *sbuf == *dbuf )  {
                    sbuf++;
                    dbuf++;
                    count++;
                  }
                else sbuf++;
         
             }
             return count;
 }




