#include"header2.h"
int  strcase_cmp(char *str1, char *str2)
{ 
    int len1,len2;
    int i=0;

    len1=strlength(str1);
    len2=strlength(str2);

    char *result;

    int n=len1 > len2 ? len1 : len2;  
    while(i < n){
     if((str1[i]-str2[i]) == 0 || (str1[i]-str2[i]) == 32 || (str1[i]-str2[i]) == -31){
    result="0";  
    i++;
    }

    else if((str1[i] > str2[i]) > 0){
        result = "1";
        i++;
    return 1;
    }
    
     else{
            result = "-1";
            i++;
            return -1;
       }
    }
   
    return 0;
}
  


