#include<stdio.h>
#include"header2.h"
char* str_tok (const char *sbuf, const char *d, int num)
{  int i,j=0;
    while( *sbuf != '\0') {
     for( i = 0; i < num; i++) {
      if(*(sbuf + i) != *d){
         printf("%c",*(sbuf + i));
      }  else printf("\n");
   } break;
   
   } 
    }
