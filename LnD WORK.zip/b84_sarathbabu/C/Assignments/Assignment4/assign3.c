
#include<stdio.h>

int main()
{
    int num = 0x99345678;
    char r = num;
    printf("%x",r);

    return 0;
}



