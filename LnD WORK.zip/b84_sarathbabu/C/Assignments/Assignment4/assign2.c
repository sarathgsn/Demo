#include<stdio.h>
int main(void)
{
   int i=1;
    union sample
    { 
        int a:5;
        int b:10;
        int c:5;
        int d:21;
        int e;
    }var1;
    var1.e = -1;
//    var1.a = 1;
 //   printf("%d",sizeof(var));
 printf("%d\n",var.b );
 printf("%d\n",var.c );
 printf("%d", var1.e);
     printf("%d\n",var1.a);
    for (i = 31; i >= 0; i--)  {
            if( (var1.a>>i) & 1) 
                    printf("1");
                else printf("0");
}

return 0;
}
