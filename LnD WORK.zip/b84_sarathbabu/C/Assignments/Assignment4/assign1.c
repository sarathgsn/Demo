#include<stdio.h>
//#pragma pack(1)
int main(void)
{
    struct sara
    {   
        short  vpi:4;
        short  gfc:4;
        int  vci:4;
        char  vpi1:4;
        short vci1:8;
        char clp:1;
        char  :0;
        char  vci2:4;
        char  hex;
       
       
    } __attribute__((packed));
    struct sara var;
    printf("%d",sizeof(var));
}
