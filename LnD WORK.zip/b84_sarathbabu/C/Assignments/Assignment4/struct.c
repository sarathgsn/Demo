#include<stdio.h>
#pragma pack (8)
int main(void)
{  
    int i;
    struct  abc {
      int a;
      char b;
      int c;
    }a1; 
    printf("%d",sizeof(a1));
return 0;
}

/*

    int  binary(int num)
    { int i;
    for(i = 31; i >= 0; i--) {
    if ((num  >> i) & 1) {
        printf("1");
    }else printf("0");
    }
   
}
*/
