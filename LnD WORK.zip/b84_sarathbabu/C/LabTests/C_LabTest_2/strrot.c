#include "header.h"

char *str_rotate(char *rstr)
{

int j;
char ch;

ch = rstr[0];

    for ( j = 0; rstr[j+1] ; j++) {
rstr[j] = rstr[j + 1];
    }
rstr[j] = ch;
return rstr;
}




int strrot( char *str, char *rstr)
{
    int i;              //i = index
   

    printf("  str_rotate %s\n",rstr);

    for ( i = 0; rstr[i] ; i++) {
    rstr = str_rotate(rstr);

    if( mystrcmp(str,rstr ) == 0) {
       return 1;
    }
    }

        return 0;
}

/*
    for ( i = 0; rstr[i] ; i++) {

ch = rstr[0];
    for ( j = 0; rstr[j+1] ; j++) {
rstr[j] = rstr[j + 1];
    }
rstr[j] = ch;

s = str_rotate(rstr);
    if( mystrcmp(str,rstr ) == 0) {
       return 1;
   }

   
   }*/
