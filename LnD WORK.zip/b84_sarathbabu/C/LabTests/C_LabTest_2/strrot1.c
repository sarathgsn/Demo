#include<stdio.h>
#define SIZE 100
int count = 0;
int strrot(char*, char*, int);
int strlength(char*);
int main(void)
{
    char str1[SIZE];
    char str2[SIZE];
    int num = 0;
    int res;
//    int count = 0;
    printf("enter the two strings");
     scanf("%s",str1);
     scanf(" %s",str2);
    strrot(str1, str2, num);
//num = strlength(str1);
//printf("%d",num);

    return 0;
}


int strrot( char *str1, char *str2, int num)
{  

//    printf("hai");
    char *org;
    int len;
    int i ;
    int j = 0;
    int k = 0;
    if( *str1 == '\0')
            return count;
    else {
        org = str1;
        len = strlength(str1);
       // printf("%d",len);
        for ( i = 0; i <= num; i++) {
        
            *(++str1 + len) = *(org + i);
        }
    }
     while ( j < len ) {   
     if ( *(str1 + j) == *(str2 + k)) {
                j++;
                k++;
                count++;
                printf("hai");
             //   printf("%d", count);
                } else j++;
     }
//     strrot(str1++, str2, num++);
     
}


int strlength(char *str1)
{
int m;
for ( m = 0 ; *(str1 + m) != '\0'; m++);
return m;
}
