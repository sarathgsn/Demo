#include<stdio.h>
int swap(int*, int*);
int main(void)
{
    int num1, num2;
    printf("enter the numbers num1 and num2\n");
    scanf("%d%d", &num1, &num2);
    swap(&num1, &num2);
    printf("after swaping num1=%d, num2=%d",num1, num2);
      return 0;
}



int swap(int *a, int *b)
{
    *a = *a ^ *b;
    *b = *a ^ *b;
    *a = *a ^ *b;
}
