#include<stdio.h>
#define SIZE 100
int i;
int big;
int small;
int bigvalue(int*, int);
int main(void)
{  
    int result;
    int result1;
    int num;
    int len;
    int arr[SIZE];
    printf("enter the elements num\n");
    scanf("%d",&num);
    printf("enter the elements\n");
    for (i = 0; i < num ; i++) {
        scanf("%d",&arr[i]);
                }   
result = bigvalue(arr, num); //invoking big value function
printf("bidvalueis=%d\n",result);
result1 = smallvalue(arr, num); // invoking small value function 
printf("small value is =%d\n",result1);
printf("difference between big value and small is largest\n");
return 0;
}


// big value function definition

 int  bigvalue(int *arr, int num ) 
 { 
 int big = *(arr + 0);
 for (i = 1; i < num; i++) {
 if( *(arr + i) > big)
     big = *(arr+i);
     }
    return big;
    } 

int smallvalue(int *arr, int num)
{
int small = *(arr+0);
for(i = 0; i < num; i++) {
    if(*(arr + i) < small) 
        small = *(arr+i);
}
return small;
}
