#include<stdio.h>
#define SIZE 100
char* strpbrk(const char*, const char*);

int main(void)
{    

    char s[SIZE];
    char accept[SIZE];
    char *char_ptr;
    printf("enter the string s\n");
    scanf("%s",s);
    printf("enter the string accept\n");
    scanf("%s",accept);
  char_ptr = strpbrk(s, accept);
   printf(" accept=%s",  char_ptr);
    return 0;
}

 char* strpbrk( const char *s, const char *accept) { 
         int i, a = 0, j = 0;        
while(* s != '\0'){
        for (i = 0; i < 4; )
        {
            if( *(s + j) == *(accept + i)) {
                a++;
                i++;
                j++;
            } else j++;
        }
        printf("%d",a);
 }
 }
