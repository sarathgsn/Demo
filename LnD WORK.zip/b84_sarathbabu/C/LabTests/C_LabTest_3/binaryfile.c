#include<stdio.h>
int main(int argc, char* argv[])
{
    char ch1, ch2;
    FILE *fp1, *fp2;
    int flag = 0;
    if ( argc < 3 ) {
       printf("enter two files\n");
     }
        else {
               fp1 = fopen(argv[1], "r");
                   if ( fp1 == NULL ) {
                      printf("file1 is unable to open\n");
                       }
                         fp2 = fopen(argv[2], "r");
                   if (fp2 == NULL ) {
                      printf("file2 is unable to open\n");
                       }
                   if ( (fp1 != NULL) && (fp2 != NULL )) {
                   while ( (ch1 = fgetc(fp1) != EOF) && ( ch2 = fgetc(fp2) != EOF)) {
                         if( ch1 == ch2) {
                              flag = 1;
                                continue;
                                   }


                            }
                      } 

            }
return 0;
}
