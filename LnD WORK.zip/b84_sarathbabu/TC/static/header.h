#ifndef _HEADER_H
#define _HEADER_H
int add(int, int);
int diff(int, int);
#endif
