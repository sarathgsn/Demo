#include"header.h"
#include<stdio.h>
int main(void)
{
    int add_result;
    int diff_result;

  add_result = add(10, 20);
  diff_result = diff(10, 20);
  printf("sum = %d, diff = %d\n", add_result, diff_result);
  printf(" pid is = %d\n", getpid());
  getchar();
  return 0;
}
