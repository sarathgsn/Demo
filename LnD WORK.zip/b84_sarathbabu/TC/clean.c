#include<stdio.h>
main()
{

printf ("sharath\n");
}
