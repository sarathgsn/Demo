#include"header.h"
#include<stdio.h>
int binary_repre(int num)
{
    int pos;
    for( pos = 31; pos < sizeof(int); pos--) {
        if ( (num >> pos) & 1)
            printf("1");
        else printf("0");
    }
}
