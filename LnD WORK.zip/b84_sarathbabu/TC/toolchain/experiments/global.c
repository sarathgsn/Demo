#include<stdio.h>
int g_var = 100;
int main(void)
{
//  char *s = "sarath";
// printf("%s\n", s); 

    int *ptr = 0x804a020;
     *ptr = 10000;
    printf("%d\n", *ptr);
//     int i = 85;
//     printf("i = %p", &i);
 //   printf("%d\n", g_var);
   printf("%d\n", g_var);
}
