#include<stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{ 
    char b[ 100 ] ;//= "stat ";

    if ( argc <= 1 ) {

        printf("cant \n");
    }

    argc = argc - 1;

    int i = 1;

    while ( argc -- ) {

/*        strcat ( b , argv [ i ] );
       strcat ( b , " " );
*/
        sprintf(b,"stat %s",argv[i]);
      i++;
   system ( b );

    }

  return 0;
} 


