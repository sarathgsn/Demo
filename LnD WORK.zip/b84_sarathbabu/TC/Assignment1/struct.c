#include<stdio.h>
//int g_var = 10;
//int g_un_var;

union s
{
    int a;
    char b;
    int d;
    int c;
}var = {10}, var2, var3;

//var.a = 10;*/
int main(void)
{// var.a = 100;
  //  printf("%d\n", sizeof(var));
}
