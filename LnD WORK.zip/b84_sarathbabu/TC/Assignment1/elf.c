//simple program for displaying ELF Header
#include<stdio.h>
int main(int argc, char *argv[])
{
    int i;   
    FILE *ptr;
    char ch;
    char  ch_var[52];
    ptr = fopen (argv[1], "r");
    if (NULL == ptr) {
        printf("file is not opened\n");
   
    }
   else {  
    fread(ch_var, 52, 1, ptr);
    printf("ELF Header:\n");
    printf("  Magic: "); 
      for ( i = 0; i < 16; i++) {
          printf(" %.2x",ch_var[i]);
      }
      printf("\n");
        if ( ch_var[4] == 1) {
            printf("  Class: ");
            printf(" \t\t\tELF32\n");
}
}
}
