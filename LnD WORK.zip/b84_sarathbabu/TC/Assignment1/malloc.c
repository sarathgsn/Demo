#include<stdio.h>
int main(void)
{
   // int num;
    int *ptr;
    ptr = malloc(4);
}
