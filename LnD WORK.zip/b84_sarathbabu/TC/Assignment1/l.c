#include<stdio.h>
/*extern int ex;  // 
int A, B, C;    // BSS
int D = 12;     // DATA
int E = 20;     // DATA
static int F, G, H;  // BSS
static int I = 92;   // DATA
static int J  = 29;  // DATA
const int M = 88;    //.RODATA
static volatile int N = 65;    // .RODATA

extern void add(int, int);

*/
//const  static volatile  int G  ;
int main(void)
{


   const static  int a = 10  ;
/* static  int K = 24;  // .DATA
    static int L;       // .BSS
    int *ptr = &N;
    *ptr = 100;
    printf("%d\n", *ptr);

    A = 34;
    B = 19;
    C = 29;
    F = 62;
    G = 26;
    H = 18;
    A = 55;
    add (2, 9); 
//    ex = 10;
//    printf("ex = %d\n", ex); */
//char *ptr = "global";
//printf("hello");
    return 0;
}
