int A, B, C;  // .bss
char W = 'a'; // .rodata
int ex = 10;  //.data

void add (int a, int b)
{
    A = 23; // stack
    return;
}
