#include <stdio.h> 
#include <unistd.h>
int main()
{    
    printf("opened new file\n");
    return 0;
}
