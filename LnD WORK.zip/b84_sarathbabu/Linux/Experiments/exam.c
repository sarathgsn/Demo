#include<stdio.h>
#include<stdlib.h>
int g_var = 100;
int main(void)
{
    int l_var = 200;
    int *p;
    p = malloc(sizeof(int));
    *p = 50;
    getchar();
    return 0;
}
