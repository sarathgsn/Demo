#include<stdio.h>
#include<fcntl.h>
int main(void)
{
   
    execlp("exce.c", NULL);
    return 0;
}
