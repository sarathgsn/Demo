
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/module.h>
void fun(int);
int myOpen(int);
//int myioctl(int, char*, char*);
struct file_operations fops = {
    .open = myOpen
//    .unlocked_ioctl = myioctl
};

int myOpen(int sarath)
{
    printk(KERN_INFO "VALUE of sarath = %d\n", sarath);
}

 int  __init
 hello_init(int mem)
{
	printk("Hello, world!\n");
    printk(KERN_INFO "value od mem =%d\n",mem);
    fun(10);
	return 0;
}

void fun (int num)
{
    printk (KERN_INFO "VALUE OF num =%d\n", num);
}
/*int myioctl(int fd, char *temp, char *temp1) 
{
    printk(KERN_INFO " VALUE of fd= %d\n", fd);
} 

*/

 void __exit
hello_exit(void)
{
	printk("Goodbye, world!\n");
}

module_exit(hello_exit);
module_init(hello_init);
 /*MODULE_LICENSE("GLP");
MODULE_AUTHOR("shrathh");
MODULE_DESCRIPTION("\"Hello, world!\" minimal module");
MODULE_VERSION("20.1.0");*/
