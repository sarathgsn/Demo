#include<stdio.h>
#include <fcntl.h>
#include<stdlib.h>
int main(void)
{   
    int fd;
    FILE *fp,*fp1;
    fp = fopen("just.txt","w");
    fd = open("/dev/mychar",O_RDWR);
    
    int  pid = fork();
    if(pid > 0)
    {  // parent process
        printf("in parent\n");
        fputs( "Global edge",fp);
        ioctl(fd, pid, NULL);

        fclose(fp);
        wait(0);
    }

    else if(pid == 0)
    { //child process
        printf("in child\n");
        fputs( "Software limited",fp);
        ioctl(fd, pid, NULL);
        fclose(fp);
        exit(0);
    }

    close(fd);
    return 0;
}
