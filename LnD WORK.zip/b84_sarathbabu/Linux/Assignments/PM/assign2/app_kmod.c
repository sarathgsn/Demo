#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int main()
{
    int fd;
   FILE *fp;

      fp = fopen("just.txt","w");

     fputs("globaledge", fp);

     fd = open("/dev/mychar",O_RDWR);

     if(fd < 0)
         perror ("unable to open the device");
     else
        printf ("File opened Suceessfully %d\n",fd);
    
    int pid = vfork();

    if (pid < 0) {
        printf("fork failed\n");
        return 0;
    } else  if (pid == 0) {

        ioctl(fd, pid, NULL);
       exit(0);
    } else {

       ioctl(fd, pid, NULL);
     //  exit(0);
    } 

    close(fp);
    close(fd);
    return 0;
}


