#include<stdio.h>
#include<unistd.h>

int main(void)
{
    FILE *fp,*fp1;
//    fp = fopen("just.txt","w");

    int  pid = fork();
    if(pid > 0)
    {  // parent process
        printf("in parent\n");
  //      fputs( "Global edge",fp);


    //    fclose(fp);
        wait(0);
    }

    else if(pid == 0)
    { //child process
        printf("in child\n");
      //  fputs( "Software limited",fp);
      //  fclose(fp);
        exit(0);
    }


    return 0;
}
