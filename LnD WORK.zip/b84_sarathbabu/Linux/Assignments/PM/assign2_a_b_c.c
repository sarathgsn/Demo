#include <stdio.h>
#include<stdlib.h>
#include<unistd.h>
int global_var = 10;
int main()
{
    int local_var = 20;
    int pid_t = vfork ();     
    int *ptr = malloc(10);
     *ptr = 30;
    if (pid_t < 0)
    {
        printf("fork failed...\n");
        return 0;
    }
    else if (pid_t == 0)       
    {
        //        global_var = 40; 
        //      local_var = 40; 
        //      *ptr = 40; 
      printf("in child %p  %p  %p\n",&global_var,&local_var,ptr);
  //      global_var = 90;
  //      local_var = 100 ;
      //  *ptr = 120;
    printf("modified global ,&global_var =  %d    %p\n",global_var,&global_var);
    printf("modified local ,&local_var =  %d    %p\n",local_var,&local_var);
    printf("modified *ptr, ptr =  %d    %p\n",*ptr,ptr);
    }
    else             
    {
     //   global_var = 90;
       // local_var = 100 ;
       // *ptr = 120;
    printf("in parent %p  %p  %p\n",&global_var,&local_var,ptr);
  //wait(0) ;
     printf("modified global_var ,&global_var =  %d    %p\n",global_var,&global_var);
     printf("modified local ,&local_var =  %d    %p\n",local_var,&local_var);
     printf("modified *ptr, ptr =  %d    %p\n",*ptr,ptr);
    }
    exit(0);
    return 0;
}
