

#include<stdio.h>

int glo = 10 ;

int main()
{
    int pid;
    int loc = 20;
  //  printf("In Parent loc %d\n", loc);
    pid = fork();
    if(pid == 0)
    {
        printf("In Child gl = %p\n", &glo);
        printf("In Child loc = %p\n", &loc);
        loc = loc + 10;
        glo = glo + 20;
        printf("In Child loc = %d\n", loc);
        printf("In Child gl = %d\n", glo);
        printf("In Child gl = %p\n", &glo);
        printf("In Child loc = %p\n", &loc);
    }
    else
    {
//       sleep(10);
       printf("In Parent loc = %d\n", loc);
       printf("In Parent gl = %d\n", glo); 
       printf("In Parent gl = %p\n", &glo);
       printf("In Parent loc = %p\n", &loc);
    }

   printf("In Thread Main Loc = %d\n", loc);
   
   printf("In Parent Id = %d\n", getpid());
   printf("In Thread Main Glo = %d\n", glo);
   return 0;
}



