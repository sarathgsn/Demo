/* basic alaram program */

#include<unistd.h>
#include<stdio.h>
#include <error.h>
#include<stdlib.h>
#include<string.h>

int main(void)
{
    
    int pid;
    int seconds;
    char line[100];
    char message[64];



    while(1) {

        printf("Alaram >>");

        if (fgets (line, sizeof(line), stdin) == NULL) {
            perror (" fgets failed\n");
            exit(0);
        }  

        if (strlen(line) <= 1) 
            continue;

        if (sscanf (line, " %d %64[^\n]", &seconds, message) < 2) {
            fprintf (stderr, "bad command\n");
        } else {

            pid = fork();
 
            if ( pid == 0) {

            sleep(seconds);
            printf("(%d) %s \n", seconds, message);
            
               } else {
                    continue;

                    exit(0);
               }
    } 

 }
    
    return 0;
}

