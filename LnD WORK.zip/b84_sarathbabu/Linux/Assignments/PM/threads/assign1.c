/* sample program for creating a thread*/
#include<stdio.h>
#include<syscall.h>
#include<pthread.h>
void *function();

int tid ;
int global_var = 10;

void *thread_function () 
{   
//    int status;
//    pthread_t ptr;
    printf ("i am in thread1\n");
    printf("address in thread1 = %p\n", &global_var);
    global_var = 100;
    tid = syscall(SYS_gettid);
    printf("thread pid = %d\n", getpid());
    printf("thread ID = %d\n",tid);
    printf("value after modification =%d\n", global_var);
    getchar();
//    printf("thread1 PID is = %d\n", getpid());

//    status = pthread_create (&ptr, NULL, function, NULL);

    return NULL;
}


/*void *function() {
    int pid; 
//    printf("address of local var = %p\n");
    printf("thread2 created by new thread\n");
    printf("address in thread2 =%p\n", &global_var);
    pid = fork();
    if (pid < 0) {
        printf("fork is failed\n");
    } else if ( pid ) {
        printf("thread created  parent \n");
    //    printf("thread created process\n");
        printf("thread created process pid is = %d\n", getpid());
    } else {
    printf("thraed child\n");
    printf("thread child pid is = %d\n", getpid());
   }
    return NULL;
}*/

int main(void)
{
    int res;
    int status;
    pthread_t ptr;
//    int pid;
    printf(" ptr value is = %d\n", ptr);    
    printf("initial address of global_var is = %p\n", &global_var);
//    pid = fork();
    
/*    if (pid < 0) {
        printf("fork is failed\n");
    } else if (pid == 0) {
 */
    status = pthread_create (&ptr, NULL, thread_function, NULL);
    printf("after calling thread the ptr value is = %d\n", ptr);
    if (status != 0) {

        printf("thread creation is failed\n");
    }
    
 // getchar();
//    pthread_exit(NULL);

  /*  } else {
      
        printf ( " i am in parent\n");
        printf(" parent  PID is = %d\n", getpid());
        getchar(); 
    }*/
     printf("main thread tid is = %d\n", syscall(SYS_gettid));
     printf("main thread pid = %d\n", getpid());
     res =  pthread_join(ptr, NULL);
        
     printf("value = %d", global_var);
     if ( res != 0) {
   
        printf ("thread failed\n");
     } 

 //   pthread_exit(NULL);
//   printf("value of global variable = %d\n", global_var);
     getchar();
//    pthread_exit(NULL);
    return 0;
}
