/* basic alaram program */

#include<pthread.h>
#include<stdio.h>
#include <error.h>
#include<stdlib.h>
#include<string.h>





typedef struct alaram 
{
    int seconds;
    char messege[64];
}ALARAM;



void *thread_function (void *);




int main(void)
{   
    ALARAM a1;
    int status;
    pthread_t ptr; 
//    int seconds;
    char line[100];
//    char message[64];

    

    while(1) {

        printf("Alaram >>");

        if (fgets (line, sizeof(line), stdin) == NULL) {
            perror (" fgets failed\n");
            exit(0);
        }  

        if (strlen(line) <= 1) 
            continue;

        if (sscanf (line, " %d %64[^\n]", &(a1.seconds), a1.messege) < 2) {
            fprintf (stderr, "bad command\n");
        } else { 

   

         status =  pthread_create (&ptr, NULL, thread_function, &a1 );
            
          
                       
            if ( status != 0) {
              
                printf("thread creation is failed\n");
          
            } else {

               continue;
            } 

 }
    
}

    return 0;
    }

void *thread_function ( void *str) 
{   
    ALARAM *jaggu = (ALARAM *) str;
    
    printf("i am in thread\n");
    sleep( jaggu->seconds );
    printf("(%d)  %s", jaggu->seconds ,jaggu->messege);

}
    
