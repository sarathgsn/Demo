#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main( int argc, char *argv[])
{
	int pid ;//to store child pid
	char * ptr[10] ;
	int loop_var ;//to use as a loop variable
	int i = 1;//for argv

	/* Storing the arguments in ptr buffer*/
	for ( loop_var = 0 ; loop_var < (argc - 1); loop_var++ ) {
		ptr[loop_var] = argv[i++] ;
	}

	/* Making last element NULL*/
	ptr[loop_var] = NULL ;

	/*creating child process */
	pid = fork () ;

	if ( 0 == pid ) {
		/* child process */
	
		/* executing commands passed through command line arguments using exec */
		execvp(argv[1], ptr) ;
	//	exit (0) ;
	} else {
		/* Parent process */

		wait (0) ;
	}

	return 0 ;
}

