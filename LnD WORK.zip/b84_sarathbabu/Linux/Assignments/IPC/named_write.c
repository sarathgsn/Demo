#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

int main()
 {  
     int res;
    int fd;
    /* Creating the named file(FIFO)
       mkfifo(<pathname>, <permission>) */
   res= mkfifo("myfifo", 0666);
   printf("res = %d\n", res);

    char arr1[80], arr2[80];
    while (1)
    {
        /* Open FIFO for write only */
        fd = open("myfifo", O_WRONLY);

        /* input from user. */

        printf("enter data\n");
        scanf("%s", arr1);

        /* Write the input  on FIFO
           and close */
        write(fd, arr1, strlen(arr1)+1);
        close(fd);

        /* Open FIFO for Read only */
        fd = open("myfifo", O_RDONLY);

        /* Read from FIFO */
        read(fd, arr2, sizeof(arr2));

        /* Print the read message */
        printf("User2: %s\n", arr2);
        close(fd);
    }
    return 0;
}
