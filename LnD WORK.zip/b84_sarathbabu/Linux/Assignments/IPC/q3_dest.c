#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#define MAX 100

int main()
{
	int fd;

	/* Creating the named pipe(FIFO) */
//	mkfifo("file", 0666);

	char arr1[MAX], arr2[MAX];
	
	while (1)
	{
		/* reading from FIFO */
		fd = open("file", O_RDONLY);
		read(fd, arr1, MAX);
		printf("msg from src: %s\n", arr1);
		close(fd);
		
		/* opening and writinginto FIFO */
		fd = open("file", O_WRONLY);
		printf("enter msg to send\n");
		fgets(arr2, MAX, stdin);
		write(fd, arr2, strlen(arr2)+1);
		close(fd);

	}
	return 0;
}
