
#include<stdlib.h>
#include<stdio.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/types.h>



int main(void)
{   char *str; 
    char *ptr;
    int rt;
    key_t mykey;

    mykey = ftok(".",0);
   
    if ( mykey == -1) {
       perror("ftok");
        exit(1);
    }

   rt = shmget(mykey, 100, 0666);
    if(rt < 0 ) {
        perror("shmget");
        exit(1);
    }

   ptr = shmat(rt, NULL, 0);


/*  memcpy(ptr, "hello world", 11);

  str = ptr;

  str += 11;
  *s = 0;
  
  while(*str != '*') 
      sleep(1);  */


   for ( str = ptr ; *str != 0; str++) {
       printf("%c", *str);
   }
   printf("\n");
   *str = '*'; 

  return 0;
}
   


