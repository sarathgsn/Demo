#include <stdio.h>
#include <unistd.h>

int main(void)
{
	int fd[2];
	char str[100];
	
	pipe(fd);  //creating pipe
	pid_t pid = fork();

	if(pid > 0){  // parent process
		printf("in parent enter data\n");
		fgets(str, 20, stdin);
		
		write(fd[1], str, sizeof(str));
		
		close(fd[1]);
		wait();
	}
	else if(pid == 0){ //child process
		sleep(10);
		printf("in child\n");
		
		read(fd[0], str, sizeof(str));
		
		printf("child received: %s\n", str);
		close(fd[0]);
	}

	else {
		printf("fork failed\n");
	}


	return 0;
}
