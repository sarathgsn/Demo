#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main(void)
{   int a;
    int p[2];
    int i = 0;
    char ch = 'a';
    pipe(p);
//    pipe2(p,O_NONBLOCK);
//    while(1) {
      close(p[1]);
        a = read(p[0], &ch, 1) ;
           perror("write");
        printf (" a = %d \n", a) ;
       // i++ ;
    
    return 0;
}
