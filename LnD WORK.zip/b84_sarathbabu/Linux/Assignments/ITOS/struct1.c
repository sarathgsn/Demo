#include<stdio.h>


struct  list_head
{
    struct list_head *next;
    struct list_head *prev;
};
struct node 
{
    int data;
    int num;
    struct list_head list;
};


int main(void)
{
    struct node var;
    struct node *ptr;
    var.data = 100;
    var.num = 200;
    struct node *first;
    first = &(var.list.next) -2;
    printf("var base ads%p\n", &var);
//    printf("%p\n", &(var.data));
//    printf("%p\n", &(var.num));
    printf(" var next ads%p\n", &(var.list.next));
//    printf("%p\n", &(var.list.prev));
//    printf("%p\n", first);
    printf("%d\n", first->data);
    printf("%d\n", first->num);
    struct node ptrr;
    printf(" ptr base ads%p\n", &ptrr);
    printf(" ptr next ads%p\n", &(ptrr.list.next));
     
    int result = (( (char*)&(ptrr.list.next))-( (char*)&ptrr));
    printf("result =%d\n", result);


    return 0;
}
