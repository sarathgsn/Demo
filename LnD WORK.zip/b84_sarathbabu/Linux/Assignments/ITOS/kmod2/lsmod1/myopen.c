
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/slab.h>


int myOpen (struct inode *inode, struct file *filep)
{
    printk (KERN_INFO "open successfully\n");
    return 0;
}

EXPORT_SYMBOL(myOpen);
