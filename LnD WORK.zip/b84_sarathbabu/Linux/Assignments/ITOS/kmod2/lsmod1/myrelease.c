#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/slab.h>




int myRelease (struct inode *in, struct file *fp)
{
    printk(KERN_INFO "file is released\n");
    return 0;
}

EXPORT_SYMBOL(myRelease);
