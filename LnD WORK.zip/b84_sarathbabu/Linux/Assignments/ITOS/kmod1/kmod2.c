#include <linux/init.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/slab.h>


//EXPORT_SYMBOL(my_ioctl);

/*struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = my_ioctl
};*/


int my_ioctl(int fd, int pid, char* temp) 
{
    printk (KERN_INFO "PID IS = %d\n", pid);
    return 0;
}

EXPORT_SYMBOL(my_ioctl);
