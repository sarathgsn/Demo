#include<stdio.h>
#include<fcntl.h>
#include<sys/ioctl.h>

int main()
{
	struct file *fd;
	int pid;
	fd = open("/dev/Raju",O_RDWR);
	pid = getpid();

	if (fd < 0)
		perror("Unable to open th device");
	else
		printf("File opened successfully %d\n", fd);
	ioctl(fd, pid, NULL);
	close (fd);

	return 0;
}
