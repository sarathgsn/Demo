#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
int i=10;
int main(void)
{
    int fd ;
    pid_t pid1;
    pid_t ppid;

    fd = open ("/dev/myChar", O_RDWR) ;
    if ( fd < 0 ) {
        perror ("unable to open the device") ;
    } else {
		pid1 = getpid();
		ppid = getppid();
                printf("%d\n",pid1);
                printf("%d\n",ppid);
        printf ("File opened succesfully %d\n", fd) ;
        printf ("address succesfully %p\n", &i) ;
             ioctl(fd, &i, NULL);

                printf("%d\n",i);
    }
    close (fd) ;
    return 0 ;
}
