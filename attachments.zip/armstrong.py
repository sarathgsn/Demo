#sum=0
#init=1
#while init<500:
#	num=init
#	while num>0:
#		digit=num%10
#		sum+=digit**3
#		num=num/10
#		if num==sum:
#			print num
#	init-=1


#Python program to check if the number provided by the user is an Armstrong number or not

# take input from the user
num = int(input("Enter a number: "))

# initialize sum
sum = 0

# find the sum of the cube of each digit
temp = num
while temp > 0:
   digit = temp % 10
   sum += digit ** 3
   temp //= 10

# display the result
if num == sum:
   print(num,"is an Armstrong number")
else:
   print(num,"is not an Armstrong number")
